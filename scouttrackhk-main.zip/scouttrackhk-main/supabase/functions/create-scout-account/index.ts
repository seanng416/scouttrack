import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    // Create admin client with service role key
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);
    
    // Get authorization header to verify the caller is a leader
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error('Missing authorization header');
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create client with user's token to verify their role
    const supabaseClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } }
    });

    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      console.error('Failed to get user:', userError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verify user is a leader
    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    if (profileError || profile?.role !== 'leader') {
      console.error('User is not a leader:', profileError);
      return new Response(
        JSON.stringify({ error: 'Only leaders can create scout accounts' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse request body
    const { name, username, password, patrolId, position } = await req.json();

    // Validate inputs
    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      return new Response(
        JSON.stringify({ error: 'Name must be at least 2 characters' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (username && (typeof username !== 'string' || !/^[a-z0-9]{3,20}$/.test(username))) {
      return new Response(
        JSON.stringify({ error: 'Username must be 3-20 lowercase alphanumeric characters' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (username && (!password || password.length < 6)) {
      return new Response(
        JSON.stringify({ error: 'Password must be at least 6 characters' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if username is already taken
    if (username) {
      const { data: existingScout } = await supabaseAdmin
        .from('scouts')
        .select('id')
        .eq('username', username)
        .maybeSingle();

      if (existingScout) {
        return new Response(
          JSON.stringify({ error: 'This User ID is already taken' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    let newUserId = null;

    // Create user account if username/password provided
    if (username && password) {
      const scoutEmail = `${username}@scout.local`;
      
      // Use admin API to create user without logging them in
      const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
        email: scoutEmail,
        password: password,
        email_confirm: true, // Auto-confirm email
        user_metadata: {
          full_name: name.trim(),
          role: 'scout',
        },
      });

      if (authError) {
        console.error('Failed to create auth user:', authError);
        return new Response(
          JSON.stringify({ error: 'Failed to create account. Please try again.' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      newUserId = authData.user?.id || null;
      console.log('Created auth user:', newUserId);
    }

    // Create scout record
    const { data: scout, error: scoutError } = await supabaseAdmin
      .from('scouts')
      .insert({
        name: name.trim(),
        patrol_id: patrolId || null,
        position: position || 'member',
        user_id: newUserId,
        username: username || null,
        created_by: user.id,
      })
      .select()
      .single();

    if (scoutError) {
      console.error('Failed to create scout:', scoutError);
      // If we created an auth user but failed to create scout, we should clean up
      if (newUserId) {
        await supabaseAdmin.auth.admin.deleteUser(newUserId);
      }
      return new Response(
        JSON.stringify({ error: 'Failed to create scout. Please try again.' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Created scout:', scout.id);

    return new Response(
      JSON.stringify({ 
        success: true, 
        scout: { id: scout.id, name: scout.name },
        hasAccount: !!newUserId 
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Unexpected error:', error);
    return new Response(
      JSON.stringify({ error: 'An unexpected error occurred' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});