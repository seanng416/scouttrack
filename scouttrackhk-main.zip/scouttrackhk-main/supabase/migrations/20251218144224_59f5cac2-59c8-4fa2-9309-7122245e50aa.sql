-- Drop and recreate scouts RLS policies as PERMISSIVE for SELECT
DROP POLICY IF EXISTS "Leaders can view all scouts" ON scouts;
DROP POLICY IF EXISTS "Scouts can view own record" ON scouts;
DROP POLICY IF EXISTS "Scouts can view patrol members" ON scouts;

-- Recreate as PERMISSIVE policies (default)
CREATE POLICY "Leaders can view all scouts" 
ON scouts 
FOR SELECT 
USING ((get_user_role(auth.uid()) = 'leader'::user_role) AND (deleted_at IS NULL));

CREATE POLICY "Scouts can view own record" 
ON scouts 
FOR SELECT 
USING ((user_id = auth.uid()) AND (deleted_at IS NULL));

CREATE POLICY "Scouts can view patrol members" 
ON scouts 
FOR SELECT 
USING ((patrol_id IS NOT NULL) AND (patrol_id = (SELECT scouts_1.patrol_id FROM scouts scouts_1 WHERE scouts_1.user_id = auth.uid() AND scouts_1.deleted_at IS NULL)) AND (deleted_at IS NULL));

-- Fix badge_progress SELECT policies
DROP POLICY IF EXISTS "Leaders can view all progress" ON badge_progress;
DROP POLICY IF EXISTS "Scouts can view own progress" ON badge_progress;
DROP POLICY IF EXISTS "Scouts can view patrol members badge progress" ON badge_progress;

CREATE POLICY "Leaders can view all progress" 
ON badge_progress 
FOR SELECT 
USING ((get_user_role(auth.uid()) = 'leader'::user_role) AND (deleted_at IS NULL));

CREATE POLICY "Scouts can view own progress" 
ON badge_progress 
FOR SELECT 
USING ((EXISTS (SELECT 1 FROM scouts WHERE scouts.id = badge_progress.scout_id AND scouts.user_id = auth.uid() AND scouts.deleted_at IS NULL)) AND (deleted_at IS NULL));

CREATE POLICY "Scouts can view patrol members badge progress" 
ON badge_progress 
FOR SELECT 
USING ((deleted_at IS NULL) AND (EXISTS (SELECT 1 FROM scouts s1 JOIN scouts s2 ON s1.patrol_id = s2.patrol_id WHERE s1.user_id = auth.uid() AND s2.id = badge_progress.scout_id AND s1.patrol_id IS NOT NULL AND s1.deleted_at IS NULL AND s2.deleted_at IS NULL)));

-- Fix requirement_progress SELECT policies
DROP POLICY IF EXISTS "Leaders can view all requirement progress" ON requirement_progress;
DROP POLICY IF EXISTS "Scouts can view own requirement progress" ON requirement_progress;

CREATE POLICY "Leaders can view all requirement progress" 
ON requirement_progress 
FOR SELECT 
USING ((get_user_role(auth.uid()) = 'leader'::user_role) AND (deleted_at IS NULL));

CREATE POLICY "Scouts can view own requirement progress" 
ON requirement_progress 
FOR SELECT 
USING ((EXISTS (SELECT 1 FROM scouts WHERE scouts.id = requirement_progress.scout_id AND scouts.user_id = auth.uid() AND scouts.deleted_at IS NULL)) AND (deleted_at IS NULL));

-- Fix badges SELECT policy
DROP POLICY IF EXISTS "Anyone authenticated can view badges" ON badges;
CREATE POLICY "Anyone authenticated can view badges" 
ON badges 
FOR SELECT 
USING (deleted_at IS NULL);

-- Fix badge_requirements SELECT policy
DROP POLICY IF EXISTS "Anyone authenticated can view requirements" ON badge_requirements;
CREATE POLICY "Anyone authenticated can view requirements" 
ON badge_requirements 
FOR SELECT 
USING (true);

-- Fix patrols SELECT policy
DROP POLICY IF EXISTS "Anyone authenticated can view patrols" ON patrols;
CREATE POLICY "Anyone authenticated can view patrols" 
ON patrols 
FOR SELECT 
USING (true);

-- Fix profiles SELECT policies  
DROP POLICY IF EXISTS "Leaders can view all profiles" ON profiles;
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;

CREATE POLICY "Leaders can view all profiles" 
ON profiles 
FOR SELECT 
USING (get_user_role(auth.uid()) = 'leader'::user_role);

CREATE POLICY "Users can view own profile" 
ON profiles 
FOR SELECT 
USING (auth.uid() = id);