-- Create user roles enum
CREATE TYPE public.user_role AS ENUM ('leader', 'scout');

-- Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  role user_role NOT NULL DEFAULT 'scout',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create badges table (managed by leaders)
CREATE TABLE public.badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT NOT NULL DEFAULT '🏅',
  category TEXT NOT NULL DEFAULT 'General',
  total_tasks INTEGER NOT NULL DEFAULT 1,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create patrols table
CREATE TABLE public.patrols (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create scouts table (managed by leaders, linked to scout user accounts)
CREATE TABLE public.scouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  patrol_id UUID REFERENCES public.patrols(id) ON DELETE SET NULL,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create badge progress table
CREATE TABLE public.badge_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scout_id UUID NOT NULL REFERENCES public.scouts(id) ON DELETE CASCADE,
  badge_id UUID NOT NULL REFERENCES public.badges(id) ON DELETE CASCADE,
  completed_tasks INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(scout_id, badge_id)
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.patrols ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scouts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.badge_progress ENABLE ROW LEVEL SECURITY;

-- Create security definer function for role checking
CREATE OR REPLACE FUNCTION public.get_user_role(user_id UUID)
RETURNS user_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = user_id;
$$;

-- Profiles policies
CREATE POLICY "Users can view own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Leaders can view all profiles" ON public.profiles
  FOR SELECT USING (public.get_user_role(auth.uid()) = 'leader');

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

-- Badges policies (leaders can CRUD, scouts can read)
CREATE POLICY "Anyone authenticated can view badges" ON public.badges
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Leaders can create badges" ON public.badges
  FOR INSERT WITH CHECK (public.get_user_role(auth.uid()) = 'leader');

CREATE POLICY "Leaders can update badges" ON public.badges
  FOR UPDATE USING (public.get_user_role(auth.uid()) = 'leader');

CREATE POLICY "Leaders can delete badges" ON public.badges
  FOR DELETE USING (public.get_user_role(auth.uid()) = 'leader');

-- Patrols policies
CREATE POLICY "Anyone authenticated can view patrols" ON public.patrols
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Leaders can manage patrols" ON public.patrols
  FOR ALL USING (public.get_user_role(auth.uid()) = 'leader');

-- Scouts policies
CREATE POLICY "Leaders can view all scouts" ON public.scouts
  FOR SELECT USING (public.get_user_role(auth.uid()) = 'leader');

CREATE POLICY "Scouts can view own record" ON public.scouts
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Leaders can manage scouts" ON public.scouts
  FOR ALL USING (public.get_user_role(auth.uid()) = 'leader');

-- Badge progress policies
CREATE POLICY "Leaders can view all progress" ON public.badge_progress
  FOR SELECT USING (public.get_user_role(auth.uid()) = 'leader');

CREATE POLICY "Scouts can view own progress" ON public.badge_progress
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.scouts WHERE scouts.id = badge_progress.scout_id AND scouts.user_id = auth.uid())
  );

CREATE POLICY "Leaders can manage progress" ON public.badge_progress
  FOR ALL USING (public.get_user_role(auth.uid()) = 'leader');

-- Trigger for profile creation on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email),
    COALESCE((NEW.raw_user_meta_data ->> 'role')::user_role, 'scout')
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_badges_updated_at BEFORE UPDATE ON public.badges
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_scouts_updated_at BEFORE UPDATE ON public.scouts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_badge_progress_updated_at BEFORE UPDATE ON public.badge_progress
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- Insert default patrols
INSERT INTO public.patrols (name) VALUES ('Eagle'), ('Wolf'), ('Bear'), ('Fox');

-- Insert default badges
INSERT INTO public.badges (name, description, icon, category, total_tasks) VALUES
  ('First Aid', 'Learn essential first aid skills to help others in emergencies', '🩹', 'Safety', 8),
  ('Camping', 'Master outdoor camping skills and wilderness survival', '⛺', 'Outdoor', 10),
  ('Navigation', 'Learn to use maps, compasses, and navigate the wilderness', '🧭', 'Skills', 6),
  ('Cooking', 'Prepare meals safely in both indoor and outdoor settings', '🍳', 'Life Skills', 8),
  ('Swimming', 'Develop water safety and swimming proficiency', '🏊', 'Fitness', 6),
  ('Hiking', 'Plan and complete hiking expeditions safely', '🥾', 'Outdoor', 8),
  ('Environmental Science', 'Understand ecosystems and environmental conservation', '🌿', 'Science', 10),
  ('Citizenship', 'Learn about community service and civic responsibility', '🏛️', 'Community', 6);