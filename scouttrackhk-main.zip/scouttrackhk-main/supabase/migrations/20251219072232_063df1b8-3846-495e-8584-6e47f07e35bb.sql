-- Fix infinite RLS recursion by making get_user_role bypass RLS safely
-- This prevents policies that call get_user_role() from recursively re-evaluating profile policies.

CREATE OR REPLACE FUNCTION public.get_user_role(user_id uuid)
RETURNS public.user_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
SET row_security = off
AS $$
  SELECT p.role
  FROM public.profiles p
  WHERE p.id = user_id
  LIMIT 1;
$$;

-- Tighten permissions: allow execution for authenticated users only
REVOKE ALL ON FUNCTION public.get_user_role(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_user_role(uuid) TO authenticated;