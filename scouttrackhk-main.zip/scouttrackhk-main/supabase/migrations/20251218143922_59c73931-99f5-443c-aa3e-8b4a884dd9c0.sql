-- Make badge-icons bucket public since icons are non-sensitive decorative images
-- that need to be viewable by both leaders and scouts
UPDATE storage.buckets SET public = true WHERE id = 'badge-icons';