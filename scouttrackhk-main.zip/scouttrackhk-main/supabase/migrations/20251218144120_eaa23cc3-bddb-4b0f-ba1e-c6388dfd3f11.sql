-- Drop and recreate soft_delete_badge with unambiguous column references
DROP FUNCTION IF EXISTS public.soft_delete_badge(uuid);
CREATE OR REPLACE FUNCTION public.soft_delete_badge(p_badge_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Soft delete the badge
  UPDATE badges SET deleted_at = now() WHERE id = p_badge_id AND deleted_at IS NULL;
  
  -- Soft delete related badge progress
  UPDATE badge_progress SET deleted_at = now() 
  WHERE badge_progress.badge_id = p_badge_id AND deleted_at IS NULL;
END;
$$;

-- Drop and recreate soft_delete_scout with unambiguous column references
DROP FUNCTION IF EXISTS public.soft_delete_scout(uuid);
CREATE OR REPLACE FUNCTION public.soft_delete_scout(p_scout_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Soft delete the scout
  UPDATE scouts SET deleted_at = now() WHERE id = p_scout_id AND deleted_at IS NULL;
  
  -- Soft delete related badge progress
  UPDATE badge_progress SET deleted_at = now() 
  WHERE badge_progress.scout_id = p_scout_id AND deleted_at IS NULL;
  
  -- Soft delete related requirement progress
  UPDATE requirement_progress SET deleted_at = now() 
  WHERE requirement_progress.scout_id = p_scout_id AND deleted_at IS NULL;
END;
$$;