-- Create badge type enum
CREATE TYPE public.badge_type AS ENUM ('proficiency', 'progressive');

-- Add new columns to badges table
ALTER TABLE public.badges 
ADD COLUMN badge_type public.badge_type NOT NULL DEFAULT 'proficiency',
ADD COLUMN icon_url TEXT;

-- Create badge requirements table for progressive badges
CREATE TABLE public.badge_requirements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  badge_id UUID NOT NULL REFERENCES public.badges(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  order_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on badge_requirements
ALTER TABLE public.badge_requirements ENABLE ROW LEVEL SECURITY;

-- RLS policies for badge_requirements
CREATE POLICY "Anyone authenticated can view requirements"
ON public.badge_requirements
FOR SELECT
USING (true);

CREATE POLICY "Leaders can manage requirements"
ON public.badge_requirements
FOR ALL
USING (get_user_role(auth.uid()) = 'leader'::user_role);

-- Add completion_date to badge_progress
ALTER TABLE public.badge_progress
ADD COLUMN completed_at TIMESTAMP WITH TIME ZONE;

-- Create requirement progress table
CREATE TABLE public.requirement_progress (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  scout_id UUID NOT NULL REFERENCES public.scouts(id) ON DELETE CASCADE,
  requirement_id UUID NOT NULL REFERENCES public.badge_requirements(id) ON DELETE CASCADE,
  completed BOOLEAN NOT NULL DEFAULT false,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(scout_id, requirement_id)
);

-- Enable RLS on requirement_progress
ALTER TABLE public.requirement_progress ENABLE ROW LEVEL SECURITY;

-- RLS policies for requirement_progress
CREATE POLICY "Leaders can view all requirement progress"
ON public.requirement_progress
FOR SELECT
USING (get_user_role(auth.uid()) = 'leader'::user_role);

CREATE POLICY "Leaders can manage requirement progress"
ON public.requirement_progress
FOR ALL
USING (get_user_role(auth.uid()) = 'leader'::user_role);

CREATE POLICY "Scouts can view own requirement progress"
ON public.requirement_progress
FOR SELECT
USING (EXISTS (
  SELECT 1 FROM scouts
  WHERE scouts.id = requirement_progress.scout_id
  AND scouts.user_id = auth.uid()
));

-- Add username field to scouts table for scout login
ALTER TABLE public.scouts
ADD COLUMN username TEXT UNIQUE;

-- Create storage bucket for badge icons
INSERT INTO storage.buckets (id, name, public)
VALUES ('badge-icons', 'badge-icons', true);

-- Storage policies for badge icons
CREATE POLICY "Anyone can view badge icons"
ON storage.objects
FOR SELECT
USING (bucket_id = 'badge-icons');

CREATE POLICY "Leaders can upload badge icons"
ON storage.objects
FOR INSERT
WITH CHECK (bucket_id = 'badge-icons' AND get_user_role(auth.uid()) = 'leader'::user_role);

CREATE POLICY "Leaders can update badge icons"
ON storage.objects
FOR UPDATE
USING (bucket_id = 'badge-icons' AND get_user_role(auth.uid()) = 'leader'::user_role);

CREATE POLICY "Leaders can delete badge icons"
ON storage.objects
FOR DELETE
USING (bucket_id = 'badge-icons' AND get_user_role(auth.uid()) = 'leader'::user_role);