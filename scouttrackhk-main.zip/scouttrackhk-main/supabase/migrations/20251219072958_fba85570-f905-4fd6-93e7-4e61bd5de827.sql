-- Fix RLS infinite recursion on public.scouts caused by self-referencing policy

-- 1) Helper: fetch current user's patrol_id without invoking RLS on scouts
CREATE OR REPLACE FUNCTION public.get_my_patrol_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
SET row_security = off
AS $$
  SELECT s.patrol_id
  FROM public.scouts s
  WHERE s.user_id = auth.uid()
    AND s.deleted_at IS NULL
  LIMIT 1;
$$;

REVOKE ALL ON FUNCTION public.get_my_patrol_id() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_my_patrol_id() TO authenticated;

-- 2) Replace the self-referencing policy with a non-recursive version
DROP POLICY IF EXISTS "Scouts can view patrol members" ON public.scouts;

CREATE POLICY "Scouts can view patrol members"
ON public.scouts
FOR SELECT
TO authenticated
USING (
  deleted_at IS NULL
  AND patrol_id IS NOT NULL
  AND patrol_id = public.get_my_patrol_id()
  AND public.get_my_patrol_id() IS NOT NULL
);
