-- Add database constraints for server-side input validation

-- Scouts table constraints
ALTER TABLE scouts ADD CONSTRAINT scouts_name_not_empty 
  CHECK (length(trim(name)) > 0);

ALTER TABLE scouts ADD CONSTRAINT scouts_name_min_length 
  CHECK (length(trim(name)) >= 2);

ALTER TABLE scouts ADD CONSTRAINT scouts_name_max_length 
  CHECK (length(name) <= 100);

ALTER TABLE scouts ADD CONSTRAINT scouts_username_format
  CHECK (username IS NULL OR username ~ '^[a-z0-9]{3,20}$');

-- Badges table constraints
ALTER TABLE badges ADD CONSTRAINT badges_name_not_empty
  CHECK (length(trim(name)) > 0);

ALTER TABLE badges ADD CONSTRAINT badges_name_max_length
  CHECK (length(name) <= 200);

ALTER TABLE badges ADD CONSTRAINT badges_description_max_length
  CHECK (description IS NULL OR length(description) <= 1000);

ALTER TABLE badges ADD CONSTRAINT badges_category_not_empty
  CHECK (length(trim(category)) > 0);

-- Patrols table constraints
ALTER TABLE patrols ADD CONSTRAINT patrols_name_not_empty
  CHECK (length(trim(name)) > 0);

ALTER TABLE patrols ADD CONSTRAINT patrols_name_max_length
  CHECK (length(name) <= 100);

-- Badge requirements constraints
ALTER TABLE badge_requirements ADD CONSTRAINT requirements_name_not_empty
  CHECK (length(trim(name)) > 0);

ALTER TABLE badge_requirements ADD CONSTRAINT requirements_name_max_length
  CHECK (length(name) <= 200);

ALTER TABLE badge_requirements ADD CONSTRAINT requirements_description_max_length
  CHECK (description IS NULL OR length(description) <= 500);