-- Add scout_position enum and column to scouts table
CREATE TYPE public.scout_position AS ENUM ('spl', 'pl', 'apl', 'member');

ALTER TABLE public.scouts 
ADD COLUMN position public.scout_position NOT NULL DEFAULT 'member';