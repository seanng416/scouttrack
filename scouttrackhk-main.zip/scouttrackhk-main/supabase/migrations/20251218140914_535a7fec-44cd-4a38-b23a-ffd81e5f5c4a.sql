-- Add soft delete support to critical tables for data recovery

-- Add deleted_at column to scouts table
ALTER TABLE scouts ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

-- Add deleted_at column to badges table
ALTER TABLE badges ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

-- Add deleted_at column to badge_progress table
ALTER TABLE badge_progress ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

-- Add deleted_at column to requirement_progress table
ALTER TABLE requirement_progress ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

-- Create index for efficient filtering of non-deleted records
CREATE INDEX IF NOT EXISTS idx_scouts_deleted_at ON scouts(deleted_at) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_badges_deleted_at ON badges(deleted_at) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_badge_progress_deleted_at ON badge_progress(deleted_at) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_requirement_progress_deleted_at ON requirement_progress(deleted_at) WHERE deleted_at IS NULL;

-- Update RLS policies to exclude soft-deleted records
-- Drop and recreate the scouts SELECT policies

DROP POLICY IF EXISTS "Leaders can view all scouts" ON scouts;
CREATE POLICY "Leaders can view all scouts" ON scouts
  FOR SELECT
  USING (get_user_role(auth.uid()) = 'leader' AND deleted_at IS NULL);

DROP POLICY IF EXISTS "Scouts can view own record" ON scouts;
CREATE POLICY "Scouts can view own record" ON scouts
  FOR SELECT
  USING (user_id = auth.uid() AND deleted_at IS NULL);

-- Update badges SELECT policy
DROP POLICY IF EXISTS "Anyone authenticated can view badges" ON badges;
CREATE POLICY "Anyone authenticated can view badges" ON badges
  FOR SELECT
  USING (deleted_at IS NULL);

-- Update badge_progress SELECT policies
DROP POLICY IF EXISTS "Leaders can view all progress" ON badge_progress;
CREATE POLICY "Leaders can view all progress" ON badge_progress
  FOR SELECT
  USING (get_user_role(auth.uid()) = 'leader' AND deleted_at IS NULL);

DROP POLICY IF EXISTS "Scouts can view own progress" ON badge_progress;
CREATE POLICY "Scouts can view own progress" ON badge_progress
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM scouts 
      WHERE scouts.id = badge_progress.scout_id 
      AND scouts.user_id = auth.uid()
      AND scouts.deleted_at IS NULL
    )
    AND deleted_at IS NULL
  );

-- Update requirement_progress SELECT policies
DROP POLICY IF EXISTS "Leaders can view all requirement progress" ON requirement_progress;
CREATE POLICY "Leaders can view all requirement progress" ON requirement_progress
  FOR SELECT
  USING (get_user_role(auth.uid()) = 'leader' AND deleted_at IS NULL);

DROP POLICY IF EXISTS "Scouts can view own requirement progress" ON requirement_progress;
CREATE POLICY "Scouts can view own requirement progress" ON requirement_progress
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM scouts 
      WHERE scouts.id = requirement_progress.scout_id 
      AND scouts.user_id = auth.uid()
      AND scouts.deleted_at IS NULL
    )
    AND deleted_at IS NULL
  );

-- Create a soft delete function for scouts
CREATE OR REPLACE FUNCTION soft_delete_scout(scout_id UUID)
RETURNS VOID AS $$
BEGIN
  -- Soft delete the scout
  UPDATE scouts SET deleted_at = now() WHERE id = scout_id AND deleted_at IS NULL;
  
  -- Soft delete related badge progress
  UPDATE badge_progress SET deleted_at = now() 
  WHERE scout_id = soft_delete_scout.scout_id AND deleted_at IS NULL;
  
  -- Soft delete related requirement progress
  UPDATE requirement_progress SET deleted_at = now() 
  WHERE scout_id = soft_delete_scout.scout_id AND deleted_at IS NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create a soft delete function for badges
CREATE OR REPLACE FUNCTION soft_delete_badge(badge_id UUID)
RETURNS VOID AS $$
BEGIN
  -- Soft delete the badge
  UPDATE badges SET deleted_at = now() WHERE id = badge_id AND deleted_at IS NULL;
  
  -- Soft delete related badge progress
  UPDATE badge_progress SET deleted_at = now() 
  WHERE badge_id = soft_delete_badge.badge_id AND deleted_at IS NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;