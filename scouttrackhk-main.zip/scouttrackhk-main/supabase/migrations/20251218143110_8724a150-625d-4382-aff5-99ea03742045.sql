-- Allow scouts to view other scouts in the same patrol
CREATE POLICY "Scouts can view patrol members" ON public.scouts
  FOR SELECT USING (
    patrol_id IS NOT NULL AND
    patrol_id = (
      SELECT patrol_id FROM public.scouts 
      WHERE user_id = auth.uid() AND deleted_at IS NULL
    ) AND deleted_at IS NULL
  );

-- Allow scouts to view badge progress of patrol members
CREATE POLICY "Scouts can view patrol members badge progress" ON public.badge_progress
  FOR SELECT USING (
    deleted_at IS NULL AND
    EXISTS (
      SELECT 1 FROM public.scouts s1
      JOIN public.scouts s2 ON s1.patrol_id = s2.patrol_id
      WHERE s1.user_id = auth.uid() 
        AND s2.id = badge_progress.scout_id
        AND s1.patrol_id IS NOT NULL
        AND s1.deleted_at IS NULL
        AND s2.deleted_at IS NULL
    )
  );