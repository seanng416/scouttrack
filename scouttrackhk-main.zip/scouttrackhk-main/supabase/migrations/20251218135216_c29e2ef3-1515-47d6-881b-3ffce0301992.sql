-- Fix 1: Add INSERT policy on profiles table
CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Fix 2: Make badge-icons bucket private and require authentication
UPDATE storage.buckets SET public = false WHERE id = 'badge-icons';

-- Update storage policy to require authentication
DROP POLICY IF EXISTS "Anyone can view badge icons" ON storage.objects;
CREATE POLICY "Authenticated users can view badge icons"
ON storage.objects
FOR SELECT
USING (bucket_id = 'badge-icons' AND auth.uid() IS NOT NULL);

-- Fix 3: Modify get_user_role to add access controls
CREATE OR REPLACE FUNCTION public.get_user_role(user_id UUID)
RETURNS user_role
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  caller_role user_role;
BEGIN
  -- Only allow users to check their own role or leaders to check any role
  SELECT role INTO caller_role FROM public.profiles WHERE id = auth.uid();
  
  IF auth.uid() = user_id OR caller_role = 'leader' THEN
    RETURN (SELECT role FROM public.profiles WHERE id = user_id);
  ELSE
    RETURN NULL;
  END IF;
END;
$$;