import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Plus, Edit, Trash2, Award, Users, ArrowLeft, Settings, Flag, Eye, Trophy } from "lucide-react";
import Header from "@/components/Header";
import ScoutCard from "@/components/ScoutCard";
import BadgeCard from "@/components/BadgeCard";
import Leaderboard, { positionLabels, type LeaderboardEntry } from "@/components/Leaderboard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import ScoutDialog from "@/components/dialogs/ScoutDialog";
import BadgeDialog from "@/components/dialogs/BadgeDialog";
import ProgressDialog from "@/components/dialogs/ProgressDialog";
import PatrolDialog from "@/components/dialogs/PatrolDialog";
import PatrolMembersDialog from "@/components/dialogs/PatrolMembersDialog";
import { toast } from "sonner";
import { handleDatabaseError } from "@/lib/errorHandler";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

type ScoutPosition = "spl" | "pl" | "apl" | "member";

interface Scout {
  id: string;
  name: string;
  patrol_id: string | null;
  user_id: string | null;
  username: string | null;
  position: ScoutPosition;
  patrol?: { name: string } | null;
}

interface Badge {
  id: string;
  name: string;
  description: string | null;
  icon: string;
  icon_url: string | null;
  category: string;
  total_tasks: number;
  badge_type: "proficiency" | "progressive";
}

interface Patrol {
  id: string;
  name: string;
}

interface BadgeProgress {
  id: string;
  scout_id: string;
  badge_id: string;
  completed_tasks: number;
  completed_at: string | null;
}

const LeaderDashboard = () => {
  const navigate = useNavigate();
  const { profile, loading: authLoading, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState("scouts");
  const [scouts, setScouts] = useState<Scout[]>([]);
  const [badges, setBadges] = useState<Badge[]>([]);
  const [patrols, setPatrols] = useState<Patrol[]>([]);
  const [progress, setProgress] = useState<BadgeProgress[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedScout, setSelectedScout] = useState<Scout | null>(null);
  const [scoutDialogOpen, setScoutDialogOpen] = useState(false);
  const [badgeDialogOpen, setBadgeDialogOpen] = useState(false);
  const [editingScout, setEditingScout] = useState<Scout | null>(null);
  const [editingBadge, setEditingBadge] = useState<Badge | null>(null);
  const [deleteScoutId, setDeleteScoutId] = useState<string | null>(null);
  const [deleteBadgeId, setDeleteBadgeId] = useState<string | null>(null);
  const [deletePatrolId, setDeletePatrolId] = useState<string | null>(null);
  const [progressDialogOpen, setProgressDialogOpen] = useState(false);
  const [selectedBadgeForProgress, setSelectedBadgeForProgress] = useState<Badge | null>(null);
  const [patrolDialogOpen, setPatrolDialogOpen] = useState(false);
  const [editingPatrol, setEditingPatrol] = useState<Patrol | null>(null);
  const [patrolMembersOpen, setPatrolMembersOpen] = useState(false);
  const [selectedPatrol, setSelectedPatrol] = useState<Patrol | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && (!profile || profile.role !== "leader")) {
      navigate("/");
    }
  }, [profile, authLoading, navigate]);

  const fetchData = async () => {
    setLoading(true);
    const [scoutsRes, badgesRes, patrolsRes, progressRes] = await Promise.all([
      supabase.from("scouts").select("*, patrol:patrols(name)"),
      supabase.from("badges").select("*"),
      supabase.from("patrols").select("*"),
      supabase.from("badge_progress").select("*"),
    ]);

    if (scoutsRes.data) setScouts(scoutsRes.data);
    if (badgesRes.data) setBadges(badgesRes.data);
    if (patrolsRes.data) setPatrols(patrolsRes.data);
    if (progressRes.data) setProgress(progressRes.data);
    setLoading(false);
  };

  useEffect(() => {
    if (profile?.role === "leader") {
      fetchData();
    }
  }, [profile]);

  const getScoutStats = (scoutId: string) => {
    const scoutProgress = progress.filter(p => p.scout_id === scoutId);
    const completedBadges = scoutProgress.filter(p => {
      const badge = badges.find(b => b.id === p.badge_id);
      return badge && p.completed_tasks === badge.total_tasks;
    }).length;
    return { totalBadges: badges.length, completedBadges };
  };

  const getBadgeProgress = (scoutId: string, badgeId: string) => {
    const prog = progress.find(p => p.scout_id === scoutId && p.badge_id === badgeId);
    const badge = badges.find(b => b.id === badgeId);
    if (!prog || !badge) return 0;
    return Math.round((prog.completed_tasks / badge.total_tasks) * 100);
  };

  const handleDeleteScout = async () => {
    if (!deleteScoutId) return;
    
    // Use soft delete by setting deleted_at timestamp
    const { error } = await supabase.rpc('soft_delete_scout', { p_scout_id: deleteScoutId });
    if (error) {
      toast.error(handleDatabaseError(error, 'delete_scout'));
    } else {
      toast.success("Scout archived successfully");
      fetchData();
    }
    setDeleteScoutId(null);
  };

  const handleDeleteBadge = async () => {
    if (!deleteBadgeId) return;
    
    // Use soft delete by setting deleted_at timestamp
    const { error } = await supabase.rpc('soft_delete_badge', { p_badge_id: deleteBadgeId });
    if (error) {
      toast.error(handleDatabaseError(error, 'delete_badge'));
    } else {
      toast.success("Badge archived successfully");
      fetchData();
    }
    setDeleteBadgeId(null);
  };

  const handleDeletePatrol = async () => {
    if (!deletePatrolId) return;
    // Check if any scouts are assigned to this patrol
    const scoutsInPatrol = scouts.filter(s => s.patrol_id === deletePatrolId);
    if (scoutsInPatrol.length > 0) {
      toast.error(`Cannot delete patrol: ${scoutsInPatrol.length} scout(s) are assigned to it`);
      setDeletePatrolId(null);
      return;
    }
    const { error } = await supabase.from("patrols").delete().eq("id", deletePatrolId);
    if (error) {
      toast.error(handleDatabaseError(error, 'delete_patrol'));
    } else {
      toast.success("Patrol deleted");
      fetchData();
    }
    setDeletePatrolId(null);
  };

  const filteredScouts = scouts.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredBadges = badges.filter(b => 
    b.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header 
        userType="leader" 
        userName={profile?.full_name || "Scout Leader"} 
        onLogout={signOut} 
      />
      
      <main className="container mx-auto px-4 py-8">
        {!selectedScout ? (
          <>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
                <TabsList>
                  <TabsTrigger value="scouts" className="gap-2">
                    <Users className="w-4 h-4" />
                    Scouts
                  </TabsTrigger>
                  <TabsTrigger value="badges" className="gap-2">
                    <Award className="w-4 h-4" />
                    Badges
                  </TabsTrigger>
                  <TabsTrigger value="patrols" className="gap-2">
                    <Flag className="w-4 h-4" />
                    Patrols
                  </TabsTrigger>
                  <TabsTrigger value="leaderboard" className="gap-2">
                    <Trophy className="w-4 h-4" />
                    Leaderboard
                  </TabsTrigger>
                </TabsList>
                
                <div className="flex gap-3">
                  {activeTab !== "leaderboard" && (
                    <>
                      <div className="relative flex-1 sm:w-64">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          placeholder={
                            activeTab === "scouts" ? "Search scouts..." : 
                            activeTab === "badges" ? "Search badges..." : 
                            "Search patrols..."
                          }
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-9"
                        />
                      </div>
                      <Button onClick={() => {
                        if (activeTab === "scouts") setScoutDialogOpen(true);
                        else if (activeTab === "badges") setBadgeDialogOpen(true);
                        else setPatrolDialogOpen(true);
                      }}>
                        <Plus className="w-4 h-4 mr-2" />
                        Add {activeTab === "scouts" ? "Scout" : activeTab === "badges" ? "Badge" : "Patrol"}
                      </Button>
                    </>
                  )}
                </div>
              </div>
              
              <TabsContent value="scouts" className="mt-0">
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredScouts.map(scout => {
                    const { totalBadges, completedBadges } = getScoutStats(scout.id);
                    return (
                      <div key={scout.id} className="relative group">
                        <ScoutCard
                          name={scout.name}
                          patrol={scout.patrol?.name || "Unassigned"}
                          position={scout.position}
                          totalBadges={totalBadges}
                          completedBadges={completedBadges}
                          onClick={() => setSelectedScout(scout)}
                        />
                        <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 bg-card/80 backdrop-blur"
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditingScout(scout);
                              setScoutDialogOpen(true);
                            }}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 bg-card/80 backdrop-blur text-destructive hover:text-destructive"
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeleteScoutId(scout.id);
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
                {filteredScouts.length === 0 && (
                  <div className="text-center py-12 text-muted-foreground">
                    {searchTerm ? "No scouts found" : "No scouts yet. Add your first scout!"}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="badges" className="mt-0">
                {(() => {
                  // Group badges by category
                  const badgesByCategory: Record<string, typeof filteredBadges> = {};
                  filteredBadges.forEach(badge => {
                    if (!badgesByCategory[badge.category]) {
                      badgesByCategory[badge.category] = [];
                    }
                    badgesByCategory[badge.category].push(badge);
                  });
                  const categories = Object.keys(badgesByCategory).sort();
                  
                  if (filteredBadges.length === 0) {
                    return (
                      <div className="text-center py-12 text-muted-foreground">
                        {searchTerm ? "No badges found" : "No badges yet. Create your first badge!"}
                      </div>
                    );
                  }
                  
                  return categories.map(category => (
                    <div key={category} className="mb-8">
                      <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-primary" />
                        {category}
                        <span className="text-sm font-normal text-muted-foreground">
                          ({badgesByCategory[category].length})
                        </span>
                      </h3>
                      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {badgesByCategory[category].map(badge => (
                          <div key={badge.id} className="relative group">
                            <BadgeCard
                              name={badge.name}
                              description={badge.description || ""}
                              icon={badge.icon}
                              iconUrl={badge.icon_url}
                              progress={0}
                              totalTasks={badge.total_tasks}
                              completedTasks={0}
                              category={badge.category}
                              badgeType={badge.badge_type}
                            />
                            <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-8 w-8 bg-card/80 backdrop-blur"
                                onClick={() => {
                                  setEditingBadge(badge);
                                  setBadgeDialogOpen(true);
                                }}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-8 w-8 bg-card/80 backdrop-blur text-destructive hover:text-destructive"
                                onClick={() => setDeleteBadgeId(badge.id)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ));
                })()}
              </TabsContent>
              
              <TabsContent value="patrols" className="mt-0">
                {(() => {
                  const filteredPatrols = patrols.filter(p => 
                    p.name.toLowerCase().includes(searchTerm.toLowerCase())
                  );
                  
                  if (filteredPatrols.length === 0) {
                    return (
                      <div className="text-center py-12 text-muted-foreground">
                        {searchTerm ? "No patrols found" : "No patrols yet. Create your first patrol!"}
                      </div>
                    );
                  }
                  
                  return (
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {filteredPatrols.map(patrol => {
                        const scoutsInPatrol = scouts.filter(s => s.patrol_id === patrol.id);
                        return (
                          <div 
                            key={patrol.id} 
                            className="relative group bg-card border rounded-xl p-5 cursor-pointer hover:border-primary/50 transition-colors"
                            onClick={() => {
                              setSelectedPatrol(patrol);
                              setPatrolMembersOpen(true);
                            }}
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                                <Flag className="w-6 h-6 text-primary" />
                              </div>
                              <div className="flex-1">
                                <h3 className="font-semibold text-foreground">{patrol.name}</h3>
                                <p className="text-sm text-muted-foreground">
                                  {scoutsInPatrol.length} scout{scoutsInPatrol.length !== 1 ? "s" : ""}
                                </p>
                              </div>
                              <Eye className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                            </div>
                            <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-8 w-8 bg-card/80 backdrop-blur"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setEditingPatrol(patrol);
                                  setPatrolDialogOpen(true);
                                }}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-8 w-8 bg-card/80 backdrop-blur text-destructive hover:text-destructive"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setDeletePatrolId(patrol.id);
                                }}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
              </TabsContent>
              
              <TabsContent value="leaderboard" className="mt-0">
                <div className="max-w-2xl mx-auto">
                  <div className="mb-6">
                    <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
                      <Trophy className="w-5 h-5 text-accent" />
                      Proficiency Badge Leaderboard
                    </h2>
                    <p className="text-sm text-muted-foreground mt-1">
                      Scouts ranked by number of completed proficiency badges
                    </p>
                  </div>
                  <Leaderboard
                    entries={scouts.map(scout => {
                      const scoutProgress = progress.filter(p => p.scout_id === scout.id);
                      const proficiencyBadgeCount = scoutProgress.filter(p => {
                        const badge = badges.find(b => b.id === p.badge_id);
                        return badge && badge.badge_type === "proficiency" && p.completed_tasks === badge.total_tasks;
                      }).length;
                      return {
                        id: scout.id,
                        name: scout.name,
                        patrolName: scout.patrol?.name,
                        position: scout.position,
                        proficiencyBadgeCount,
                      };
                    })}
                  />
                </div>
              </TabsContent>
            </Tabs>
          </>
        ) : (
          <>
            <div className="mb-8 fade-in">
              <Button 
                variant="ghost" 
                className="mb-4"
                onClick={() => setSelectedScout(null)}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Roster
              </Button>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center text-2xl">
                    👤
                  </div>
                  <div>
                    <h1 className="text-3xl font-bold text-foreground">{selectedScout.name}</h1>
                    <p className="text-muted-foreground">{selectedScout.patrol?.name || "Unassigned"} Patrol</p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  onClick={() => {
                    setEditingScout(selectedScout);
                    setScoutDialogOpen(true);
                  }}
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Edit Scout
                </Button>
              </div>
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-foreground mb-4">Badge Progress</h2>
              <p className="text-sm text-muted-foreground mb-4">Click on a badge to update progress</p>
            </div>
            
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {badges.map(badge => {
                const prog = progress.find(p => p.scout_id === selectedScout.id && p.badge_id === badge.id);
                const completedTasks = prog?.completed_tasks || 0;
                const progressPercent = Math.round((completedTasks / badge.total_tasks) * 100);
                
                return (
                  <div 
                    key={badge.id} 
                    className="cursor-pointer"
                    onClick={() => {
                      setSelectedBadgeForProgress(badge);
                      setProgressDialogOpen(true);
                    }}
                  >
                    <BadgeCard
                      name={badge.name}
                      description={badge.description || ""}
                      icon={badge.icon}
                      iconUrl={badge.icon_url}
                      progress={progressPercent}
                      totalTasks={badge.total_tasks}
                      completedTasks={completedTasks}
                      category={badge.category}
                      badgeType={badge.badge_type}
                      completedAt={prog?.completed_at}
                    />
                  </div>
                );
              })}
            </div>
          </>
        )}
      </main>

      <ScoutDialog
        open={scoutDialogOpen}
        onOpenChange={(open) => {
          setScoutDialogOpen(open);
          if (!open) setEditingScout(null);
        }}
        scout={editingScout}
        patrols={patrols}
        onSuccess={() => {
          fetchData();
          if (editingScout && selectedScout?.id === editingScout.id) {
            setSelectedScout(null);
          }
        }}
      />

      <BadgeDialog
        open={badgeDialogOpen}
        onOpenChange={(open) => {
          setBadgeDialogOpen(open);
          if (!open) setEditingBadge(null);
        }}
        badge={editingBadge}
        onSuccess={fetchData}
      />

      <PatrolDialog
        open={patrolDialogOpen}
        onOpenChange={(open) => {
          setPatrolDialogOpen(open);
          if (!open) setEditingPatrol(null);
        }}
        patrol={editingPatrol}
        onSuccess={fetchData}
      />

      {selectedPatrol && (
        <PatrolMembersDialog
          open={patrolMembersOpen}
          onOpenChange={(open) => {
            setPatrolMembersOpen(open);
            if (!open) setSelectedPatrol(null);
          }}
          patrolId={selectedPatrol.id}
          patrolName={selectedPatrol.name}
        />
      )}

      {selectedScout && selectedBadgeForProgress && (
        <ProgressDialog
          open={progressDialogOpen}
          onOpenChange={setProgressDialogOpen}
          scoutId={selectedScout.id}
          scoutName={selectedScout.name}
          badge={selectedBadgeForProgress}
          currentProgress={progress.find(p => p.scout_id === selectedScout.id && p.badge_id === selectedBadgeForProgress.id)}
          onSuccess={fetchData}
        />
      )}

      <AlertDialog open={!!deleteScoutId} onOpenChange={() => setDeleteScoutId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Scout?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this scout and all their badge progress. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteScout} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!deleteBadgeId} onOpenChange={() => setDeleteBadgeId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Badge?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this badge and all related progress data. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteBadge} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!deletePatrolId} onOpenChange={() => setDeletePatrolId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Patrol?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this patrol. Make sure no scouts are assigned to it first.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeletePatrol} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default LeaderDashboard;
