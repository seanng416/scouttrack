import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Compass, Users, User, Eye, EyeOff, WifiOff, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { z } from "zod";

const leaderLoginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const scoutLoginSchema = z.object({
  username: z.string().min(3, "User ID must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const signupSchema = leaderLoginSchema.extend({
  fullName: z.string().min(2, "Name must be at least 2 characters"),
});

const Auth = () => {
  const navigate = useNavigate();
  const { user, profile, loading, connectionError, retryConnection, signIn, signUp } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [isLeader, setIsLeader] = useState(true);
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!loading && user && profile) {
      if (profile.role === "leader") {
        navigate("/leader");
      } else {
        navigate("/scout");
      }
    }
  }, [user, profile, loading, navigate]);

  const validateForm = () => {
    setErrors({});
    try {
      if (isLogin) {
        if (isLeader) {
          leaderLoginSchema.parse({ email, password });
        } else {
          scoutLoginSchema.parse({ username, password });
        }
      } else {
        signupSchema.parse({ email, password, fullName });
      }
      return true;
    } catch (err) {
      if (err instanceof z.ZodError) {
        const newErrors: Record<string, string> = {};
        err.errors.forEach((e) => {
          if (e.path[0]) {
            newErrors[e.path[0] as string] = e.message;
          }
        });
        setErrors(newErrors);
      }
      return false;
    }
  };

  const handleScoutLogin = async () => {
    const genericError = "Invalid username or password.";
    
    try {
      // Use edge function to securely lookup username and authenticate
      const { data, error } = await supabase.functions.invoke('scout-login', {
        body: { 
          username: username.trim().toLowerCase(), 
          password 
        }
      });

      if (error) {
        console.error('Scout login error:', error);
        toast.error(genericError);
        return;
      }

      if (data?.error) {
        toast.error(genericError);
        return;
      }

      if (data?.session) {
        // Set the session manually since we got it from the edge function
        await supabase.auth.setSession({
          access_token: data.session.access_token,
          refresh_token: data.session.refresh_token
        });
        toast.success("Welcome back!");
      } else {
        toast.error(genericError);
      }
    } catch (err) {
      console.error('Scout login unexpected error:', err);
      toast.error(genericError);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setSubmitting(true);
    
    if (isLogin) {
      if (isLeader) {
        const { error } = await signIn(email, password);
        if (error) {
          toast.error(error.message === "Invalid login credentials" 
            ? "Invalid email or password" 
            : error.message);
        }
      } else {
        await handleScoutLogin();
      }
    } else {
      const { error } = await signUp(email, password, fullName, "leader");
      if (error) {
        if (error.message.includes("already registered")) {
          toast.error("This email is already registered. Please sign in instead.");
        } else {
          toast.error(error.message);
        }
      } else {
        toast.success("Account created successfully!");
      }
    }
    
    setSubmitting(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4 p-4">
        <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center mb-2">
          <Compass className="w-6 h-6 text-primary-foreground" />
        </div>
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        <p className="text-muted-foreground text-sm">Connecting...</p>
      </div>
    );
  }

  if (connectionError) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-6 p-4">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center">
          <WifiOff className="w-8 h-8 text-muted-foreground" />
        </div>
        <div className="text-center max-w-sm">
          <h2 className="text-xl font-semibold text-foreground mb-2">Connection Problem</h2>
          <p className="text-muted-foreground text-sm">
            Unable to connect to the server. Please check your internet connection and try again.
          </p>
        </div>
        <Button onClick={retryConnection} className="gap-2">
          <RefreshCw className="w-4 h-4" />
          Try Again
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-primary p-12 flex-col justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-primary-foreground/20 rounded-xl flex items-center justify-center">
            <Compass className="w-7 h-7 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-primary-foreground">ScoutTrack</h1>
            <p className="text-sm text-primary-foreground/70">Badge Progress Tracker</p>
          </div>
        </div>
        
        <div>
          <h2 className="text-4xl font-bold text-primary-foreground mb-4">
            Track achievements.<br />Celebrate growth.
          </h2>
          <p className="text-primary-foreground/80 text-lg">
            Help scouts reach their full potential with organized badge tracking and progress monitoring.
          </p>
        </div>
        
        <div className="flex gap-8 text-primary-foreground/70">
          <div>
            <p className="text-3xl font-bold text-primary-foreground">8+</p>
            <p className="text-sm">Badge Categories</p>
          </div>
          <div>
            <p className="text-3xl font-bold text-primary-foreground">100%</p>
            <p className="text-sm">Progress Tracking</p>
          </div>
        </div>
      </div>
      
      {/* Right side - Form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex items-center gap-3 mb-8 justify-center">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Compass className="w-6 h-6 text-primary-foreground" />
            </div>
            <h1 className="text-xl font-bold text-foreground">ScoutTrack</h1>
          </div>
          
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-foreground">
              {isLogin ? "Welcome back" : "Create Leader Account"}
            </h2>
            <p className="text-muted-foreground mt-2">
              {isLogin 
                ? "Sign in to continue tracking progress" 
                : "Scout Leaders can create and manage troops"}
            </p>
          </div>
          
          {/* Role selector for login */}
          {isLogin && (
            <div className="flex gap-3 mb-6">
              <button
                type="button"
                onClick={() => setIsLeader(true)}
                className={`flex-1 p-4 rounded-xl border-2 transition-all ${
                  isLeader 
                    ? "border-primary bg-primary/5" 
                    : "border-border hover:border-primary/50"
                }`}
              >
                <Users className={`w-6 h-6 mx-auto mb-2 ${isLeader ? "text-primary" : "text-muted-foreground"}`} />
                <p className={`text-sm font-medium ${isLeader ? "text-primary" : "text-muted-foreground"}`}>
                  Scout Leader
                </p>
                <p className="text-xs text-muted-foreground mt-1">Login with email</p>
              </button>
              <button
                type="button"
                onClick={() => setIsLeader(false)}
                className={`flex-1 p-4 rounded-xl border-2 transition-all ${
                  !isLeader 
                    ? "border-primary bg-primary/5" 
                    : "border-border hover:border-primary/50"
                }`}
              >
                <User className={`w-6 h-6 mx-auto mb-2 ${!isLeader ? "text-primary" : "text-muted-foreground"}`} />
                <p className={`text-sm font-medium ${!isLeader ? "text-primary" : "text-muted-foreground"}`}>
                  Scout Member
                </p>
                <p className="text-xs text-muted-foreground mt-1">Login with User ID</p>
              </button>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Enter your full name"
                  className="mt-1"
                />
                {errors.fullName && <p className="text-sm text-destructive mt-1">{errors.fullName}</p>}
              </div>
            )}
            
            {/* Leader email login or Scout username login */}
            {isLogin && !isLeader ? (
              <div>
                <Label htmlFor="username">User ID</Label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your User ID"
                  className="mt-1"
                />
                {errors.username && <p className="text-sm text-destructive mt-1">{errors.username}</p>}
              </div>
            ) : (
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="mt-1"
                />
                {errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}
              </div>
            )}
            
            <div>
              <Label htmlFor="password">Password</Label>
              <div className="relative mt-1">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {errors.password && <p className="text-sm text-destructive mt-1">{errors.password}</p>}
            </div>
            
            <Button type="submit" className="w-full" size="lg" disabled={submitting}>
              {submitting ? "Please wait..." : isLogin ? "Sign In" : "Create Account"}
            </Button>
          </form>
          
          {/* Only leaders can sign up */}
          {isLeader && (
            <p className="text-center mt-6 text-muted-foreground">
              {isLogin ? "Don't have an account?" : "Already have an account?"}{" "}
              <button
                type="button"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setErrors({});
                }}
                className="text-primary font-medium hover:underline"
              >
                {isLogin ? "Sign up as Leader" : "Sign in"}
              </button>
            </p>
          )}
          
          {!isLeader && isLogin && (
            <p className="text-center mt-6 text-sm text-muted-foreground">
              Scout accounts are created by your Scout Leader.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Auth;
