import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Trophy, Target, Star, Users, Flag } from "lucide-react";
import Header from "@/components/Header";
import BadgeCard from "@/components/BadgeCard";
import Leaderboard, { type LeaderboardEntry } from "@/components/Leaderboard";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PatrolMembersDialog from "@/components/dialogs/PatrolMembersDialog";
import BadgeRequirementsDialog from "@/components/dialogs/BadgeRequirementsDialog";

type ScoutPosition = "spl" | "pl" | "apl" | "member";

interface Badge {
  id: string;
  name: string;
  description: string | null;
  icon: string;
  icon_url: string | null;
  category: string;
  total_tasks: number;
  badge_type: "proficiency" | "progressive";
}

interface BadgeProgress {
  id: string;
  badge_id: string;
  scout_id?: string;
  completed_tasks: number;
  completed_at: string | null;
}

interface Scout {
  id: string;
  name: string;
  patrol_id: string | null;
  position: ScoutPosition;
  patrol?: { name: string } | null;
}

const ScoutDashboard = () => {
  const navigate = useNavigate();
  const { user, profile, loading: authLoading, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState("badges");
  const [filter, setFilter] = useState<"all" | "in-progress" | "completed">("all");
  const [badges, setBadges] = useState<Badge[]>([]);
  const [progress, setProgress] = useState<BadgeProgress[]>([]);
  const [allScouts, setAllScouts] = useState<{ id: string; name: string; patrol_id: string | null; position: ScoutPosition; patrol?: { name: string } | null }[]>([]);
  const [allProgress, setAllProgress] = useState<BadgeProgress[]>([]);
  const [scout, setScout] = useState<Scout | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Dialog states
  const [patrolMembersOpen, setPatrolMembersOpen] = useState(false);
  const [selectedBadge, setSelectedBadge] = useState<Badge | null>(null);
  const [requirementsDialogOpen, setRequirementsDialogOpen] = useState(false);

  useEffect(() => {
    if (!authLoading && (!profile || profile.role !== "scout")) {
      navigate("/");
    }
  }, [profile, authLoading, navigate]);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      // Fetch scout record linked to this user
      const { data: scoutData } = await supabase
        .from("scouts")
        .select("*, patrol:patrols(name)")
        .eq("user_id", user.id)
        .maybeSingle();

      if (scoutData) {
        setScout(scoutData);
        
        // Fetch badge progress for this scout
        const { data: progressData } = await supabase
          .from("badge_progress")
          .select("*")
          .eq("scout_id", scoutData.id);
        
        if (progressData) setProgress(progressData);
      }

      // Fetch all badges
      const { data: badgesData } = await supabase
        .from("badges")
        .select("*");
      
      if (badgesData) setBadges(badgesData);

      // Fetch all scouts and their progress for leaderboard (only patrol members visible)
      const { data: allScoutsData } = await supabase
        .from("scouts")
        .select("id, name, patrol_id, position, patrol:patrols(name)");
      
      if (allScoutsData) setAllScouts(allScoutsData as typeof allScouts);

      // Fetch all badge progress for leaderboard
      const { data: allProgressData } = await supabase
        .from("badge_progress")
        .select("*");
      
      if (allProgressData) setAllProgress(allProgressData);
      
      setLoading(false);
    };

    if (profile?.role === "scout") {
      fetchData();
    }
  }, [user, profile]);

  const getBadgeProgress = (badgeId: string) => {
    const prog = progress.find(p => p.badge_id === badgeId);
    const badge = badges.find(b => b.id === badgeId);
    if (!prog || !badge) return { percent: 0, completed: 0, total: badge?.total_tasks || 0, completedAt: null };
    return {
      percent: Math.round((prog.completed_tasks / badge.total_tasks) * 100),
      completed: prog.completed_tasks,
      total: badge.total_tasks,
      completedAt: prog.completed_at,
    };
  };

  const filteredBadges = badges.filter(badge => {
    const { percent } = getBadgeProgress(badge.id);
    if (filter === "completed") return percent === 100;
    if (filter === "in-progress") return percent > 0 && percent < 100;
    return true;
  });

  // Group badges by category
  const badgesByCategory = useMemo(() => {
    const grouped: Record<string, Badge[]> = {};
    filteredBadges.forEach(badge => {
      if (!grouped[badge.category]) {
        grouped[badge.category] = [];
      }
      grouped[badge.category].push(badge);
    });
    return grouped;
  }, [filteredBadges]);

  const categories = Object.keys(badgesByCategory).sort();

  const completedCount = badges.filter(b => getBadgeProgress(b.id).percent === 100).length;
  const inProgressCount = badges.filter(b => {
    const p = getBadgeProgress(b.id).percent;
    return p > 0 && p < 100;
  }).length;

  const handleBadgeClick = (badge: Badge) => {
    if (badge.badge_type === "progressive") {
      setSelectedBadge(badge);
      setRequirementsDialogOpen(true);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!scout) {
    return (
      <div className="min-h-screen bg-background">
        <Header 
          userType="scout" 
          userName={profile?.full_name || "Scout"} 
          onLogout={signOut} 
        />
        <main className="container mx-auto px-4 py-16 text-center">
          <div className="max-w-md mx-auto">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
              <Star className="w-10 h-10 text-muted-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground mb-2">Welcome, {profile?.full_name}!</h1>
            <p className="text-muted-foreground">
              Your Scout Leader hasn't linked your account to a scout record yet. 
              Please contact them to get started with badge tracking.
            </p>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header 
        userType="scout" 
        userName={scout.name} 
        onLogout={signOut} 
      />
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 fade-in">
          <h1 className="text-3xl font-bold text-foreground mb-2">My Scout Dashboard</h1>
          <p className="text-muted-foreground">
            {scout.patrol?.name ? `${scout.patrol.name} Patrol` : "Track your achievements and continue your scouting journey"}
          </p>
        </div>
        
        <div className="grid grid-cols-3 gap-4 mb-8 fade-in stagger-1">
          <div className="bg-card rounded-xl p-5 border border-border">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
                <Trophy className="w-5 h-5 text-accent" />
              </div>
            </div>
            <p className="text-2xl font-bold text-foreground">{completedCount}</p>
            <p className="text-sm text-muted-foreground">Badges Earned</p>
          </div>
          
          <div className="bg-card rounded-xl p-5 border border-border">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                <Target className="w-5 h-5 text-primary" />
              </div>
            </div>
            <p className="text-2xl font-bold text-foreground">{inProgressCount}</p>
            <p className="text-sm text-muted-foreground">In Progress</p>
          </div>
          
          <div className="bg-card rounded-xl p-5 border border-border">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                <Star className="w-5 h-5 text-muted-foreground" />
              </div>
            </div>
            <p className="text-2xl font-bold text-foreground">{badges.length}</p>
            <p className="text-sm text-muted-foreground">Total Badges</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="fade-in stagger-2">
          <TabsList className="mb-6">
            <TabsTrigger value="badges" className="gap-2">
              <Trophy className="w-4 h-4" />
              My Badges
            </TabsTrigger>
            {scout.patrol_id && (
              <TabsTrigger value="patrol" className="gap-2">
                <Users className="w-4 h-4" />
                My Patrol
              </TabsTrigger>
            )}
            <TabsTrigger value="leaderboard" className="gap-2">
              <Star className="w-4 h-4" />
              Leaderboard
            </TabsTrigger>
          </TabsList>

          <TabsContent value="badges" className="mt-0">
            <div className="flex items-center gap-2 mb-6">
              {(["all", "in-progress", "completed"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    filter === f
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}
                >
                  {f === "all" ? "All Badges" : f === "in-progress" ? "In Progress" : "Completed"}
                </button>
              ))}
            </div>
            
            {/* Badges grouped by category */}
            {categories.map(category => (
              <div key={category} className="mb-8 fade-in">
                <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-primary" />
                  {category}
                  <span className="text-sm font-normal text-muted-foreground">
                    ({badgesByCategory[category].length} badges)
                  </span>
                </h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {badgesByCategory[category].map(badge => {
                    const { percent, completed, total, completedAt } = getBadgeProgress(badge.id);
                    const isClickable = badge.badge_type === "progressive";
                    return (
                      <div
                        key={badge.id}
                        className={isClickable ? "cursor-pointer" : ""}
                        onClick={() => handleBadgeClick(badge)}
                      >
                        <BadgeCard
                          name={badge.name}
                          description={badge.description || ""}
                          icon={badge.icon}
                          iconUrl={badge.icon_url}
                          progress={percent}
                          totalTasks={total}
                          completedTasks={completed}
                          category={badge.category}
                          badgeType={badge.badge_type}
                          completedAt={completedAt}
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
            
            {filteredBadges.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                No badges found in this category.
              </div>
            )}
          </TabsContent>

          {scout.patrol_id && (
            <TabsContent value="patrol" className="mt-0">
              <div 
                className="bg-card border rounded-xl p-6 cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => setPatrolMembersOpen(true)}
              >
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Flag className="w-8 h-8 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-foreground">{scout.patrol?.name} Patrol</h3>
                    <p className="text-muted-foreground">Click to view patrol members and their badges</p>
                  </div>
                  <Users className="w-6 h-6 text-muted-foreground" />
                </div>
              </div>
            </TabsContent>
          )}

          <TabsContent value="leaderboard" className="mt-0">
            <div className="max-w-2xl mx-auto">
              <div className="mb-6">
                <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-accent" />
                  Proficiency Badge Leaderboard
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Scouts ranked by number of completed proficiency badges
                </p>
              </div>
              <Leaderboard
                currentScoutId={scout.id}
                entries={allScouts.map(s => {
                  const scoutProg = allProgress.filter(p => p.scout_id === s.id);
                  const proficiencyBadgeCount = scoutProg.filter(p => {
                    const badge = badges.find(b => b.id === p.badge_id);
                    return badge && badge.badge_type === "proficiency" && p.completed_tasks === badge.total_tasks;
                  }).length;
                  return {
                    id: s.id,
                    name: s.name,
                    patrolName: s.patrol?.name,
                    position: s.position,
                    proficiencyBadgeCount,
                  };
                })}
              />
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Patrol Members Dialog */}
      {scout.patrol_id && scout.patrol?.name && (
        <PatrolMembersDialog
          open={patrolMembersOpen}
          onOpenChange={setPatrolMembersOpen}
          patrolId={scout.patrol_id}
          patrolName={scout.patrol.name}
        />
      )}

      {/* Badge Requirements Dialog */}
      {selectedBadge && (
        <BadgeRequirementsDialog
          open={requirementsDialogOpen}
          onOpenChange={(open) => {
            setRequirementsDialogOpen(open);
            if (!open) setSelectedBadge(null);
          }}
          badge={selectedBadge}
          scoutId={scout.id}
        />
      )}
    </div>
  );
};

export default ScoutDashboard;
