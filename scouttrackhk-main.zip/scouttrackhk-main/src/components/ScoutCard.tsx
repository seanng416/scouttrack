import { User, Award } from "lucide-react";

type ScoutPosition = "spl" | "pl" | "apl" | "member";

const positionLabels: Record<ScoutPosition, string> = {
  spl: "團隊長 (SPL)",
  pl: "小隊長 (PL)",
  apl: "副隊長 (APL)",
  member: "團員",
};

interface ScoutCardProps {
  name: string;
  avatar?: string;
  patrol: string;
  position?: ScoutPosition;
  totalBadges: number;
  completedBadges: number;
  onClick?: () => void;
}

const ScoutCard = ({ name, avatar, patrol, position = "member", totalBadges, completedBadges, onClick }: ScoutCardProps) => {
  const progressPercent = (completedBadges / totalBadges) * 100;
  
  return (
    <div 
      onClick={onClick}
      className="bg-card rounded-xl p-5 shadow-sm border border-border card-hover cursor-pointer"
    >
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
          {avatar ? (
            <img src={avatar} alt={name} className="w-full h-full rounded-full object-cover" />
          ) : (
            <User className="w-6 h-6 text-muted-foreground" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-foreground truncate">{name}</h3>
          <p className="text-sm text-muted-foreground">{patrol} Patrol</p>
          <p className="text-xs text-primary/80 font-medium">{positionLabels[position]}</p>
        </div>
        <div className="flex items-center gap-1 text-accent">
          <Award className="w-5 h-5" />
          <span className="font-semibold">{completedBadges}</span>
        </div>
      </div>
      
      <div className="mt-4">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-muted-foreground">Badge Progress</span>
          <span className="font-medium text-foreground">{completedBadges}/{totalBadges}</span>
        </div>
        <div className="h-2 bg-progress-bg rounded-full overflow-hidden">
          <div 
            className="h-full bg-progress-fill rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export default ScoutCard;
