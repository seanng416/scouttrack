import { cn } from "@/lib/utils";

interface BadgeCardProps {
  name: string;
  description: string;
  icon: string;
  iconUrl?: string | null;
  progress: number;
  totalTasks: number;
  completedTasks: number;
  category: string;
  badgeType?: "proficiency" | "progressive";
  completedAt?: string | null;
}

const BadgeCard = ({ 
  name, 
  description, 
  icon, 
  iconUrl,
  progress, 
  totalTasks, 
  completedTasks, 
  category,
  badgeType = "proficiency",
  completedAt,
}: BadgeCardProps) => {
  const isComplete = progress === 100;
  
  return (
    <div className={cn(
      "bg-card rounded-xl p-5 shadow-sm border border-border card-hover",
      isComplete && "ring-2 ring-accent"
    )}>
      <div className="flex items-start gap-4">
        <div className={cn(
          "w-14 h-14 rounded-xl flex items-center justify-center text-2xl overflow-hidden shrink-0",
          isComplete ? "bg-accent/20" : "bg-muted"
        )}>
          {iconUrl ? (
            <img src={iconUrl} alt={name} className="w-full h-full object-cover" />
          ) : (
            icon
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              {category}
            </span>
            <span className={cn(
              "text-xs px-2 py-0.5 rounded-full",
              badgeType === "progressive" 
                ? "bg-primary/10 text-primary" 
                : "bg-muted text-muted-foreground"
            )}>
              {badgeType === "progressive" ? "Progressive" : "Proficiency"}
            </span>
            {isComplete && (
              <span className="text-xs font-semibold text-accent bg-accent/10 px-2 py-0.5 rounded-full">
                Complete!
              </span>
            )}
          </div>
          <h3 className="font-semibold text-foreground truncate">{name}</h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{description}</p>
        </div>
      </div>
      
      <div className="mt-4">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-muted-foreground">Progress</span>
          <span className="font-medium text-foreground">
            {badgeType === "progressive" ? `${completedTasks}/${totalTasks} requirements` : (isComplete ? "Completed" : "Not started")}
          </span>
        </div>
        <div className="h-2 bg-progress-bg rounded-full overflow-hidden">
          <div 
            className={cn(
              "h-full rounded-full transition-all duration-500",
              isComplete ? "bg-accent" : "bg-progress-fill"
            )}
            style={{ width: `${progress}%` }}
          />
        </div>
        {isComplete && completedAt && (
          <p className="text-xs text-muted-foreground mt-2">
            Completed on {new Date(completedAt).toLocaleDateString()}
          </p>
        )}
      </div>
    </div>
  );
};

export default BadgeCard;
