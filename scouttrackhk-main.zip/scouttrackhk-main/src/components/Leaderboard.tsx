import { Trophy, Medal, Award } from "lucide-react";

interface LeaderboardEntry {
  id: string;
  name: string;
  patrolName?: string;
  position: string;
  proficiencyBadgeCount: number;
}

interface LeaderboardProps {
  entries: LeaderboardEntry[];
  currentScoutId?: string;
}

const positionLabels: Record<string, string> = {
  spl: "團隊長 (SPL)",
  pl: "小隊長 (PL)",
  apl: "副隊長 (APL)",
  member: "團員 (Member)",
};

const Leaderboard = ({ entries, currentScoutId }: LeaderboardProps) => {
  // Sort by proficiency badge count descending
  const sorted = [...entries].sort((a, b) => b.proficiencyBadgeCount - a.proficiencyBadgeCount);

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Trophy className="w-5 h-5 text-yellow-500" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-gray-400" />;
    if (rank === 3) return <Award className="w-5 h-5 text-amber-600" />;
    return <span className="w-5 h-5 flex items-center justify-center text-sm font-medium text-muted-foreground">{rank}</span>;
  };

  const getRankBg = (rank: number, isCurrentScout: boolean) => {
    if (isCurrentScout) return "bg-primary/10 border-primary/30";
    if (rank === 1) return "bg-yellow-500/10 border-yellow-500/30";
    if (rank === 2) return "bg-gray-400/10 border-gray-400/30";
    if (rank === 3) return "bg-amber-600/10 border-amber-600/30";
    return "bg-card border-border";
  };

  return (
    <div className="space-y-2">
      {sorted.map((entry, index) => {
        const rank = index + 1;
        const isCurrentScout = entry.id === currentScoutId;
        return (
          <div
            key={entry.id}
            className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${getRankBg(rank, isCurrentScout)}`}
          >
            <div className="w-8 flex justify-center">
              {getRankIcon(rank)}
            </div>
            <div className="flex-1 min-w-0">
              <p className={`font-medium truncate ${isCurrentScout ? "text-primary" : "text-foreground"}`}>
                {entry.name}
                {isCurrentScout && <span className="ml-2 text-xs text-primary">(You)</span>}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                {entry.patrolName || "Unassigned"} · {positionLabels[entry.position] || entry.position}
              </p>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-accent/20 rounded-full">
              <Trophy className="w-3.5 h-3.5 text-accent" />
              <span className="text-sm font-semibold text-accent">{entry.proficiencyBadgeCount}</span>
            </div>
          </div>
        );
      })}
      {sorted.length === 0 && (
        <div className="text-center py-8 text-muted-foreground">
          No scouts to display
        </div>
      )}
    </div>
  );
};

export default Leaderboard;
export { positionLabels };
export type { LeaderboardEntry };
