import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Upload, X, Plus, Trash2, GripVertical } from "lucide-react";
import { handleDatabaseError } from "@/lib/errorHandler";

interface Badge {
  id: string;
  name: string;
  description: string | null;
  icon: string;
  icon_url: string | null;
  category: string;
  total_tasks: number;
  badge_type: "proficiency" | "progressive";
}

interface Requirement {
  id?: string;
  name: string;
  description: string;
  order_index: number;
}

interface BadgeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  badge?: Badge | null;
  onSuccess: () => void;
}

const BADGE_ICONS = ["🏅", "🩹", "⛺", "🧭", "🍳", "🏊", "🥾", "🌿", "🏛️", "🔥", "🎨", "📸", "🎵", "⚽", "🚴", "🧗", "🎯", "🌟"];
const PROFICIENCY_CATEGORIES = ["興趣組", "技能組", "服務組", "教導組", "航空活動", "水上活動", "其他"];
const PROGRESSIVE_CATEGORIES = ["進度性獎章"];

const BadgeDialog = ({ open, onOpenChange, badge, onSuccess }: BadgeDialogProps) => {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [icon, setIcon] = useState("🏅");
  const [iconUrl, setIconUrl] = useState<string | null>(null);
  const [category, setCategory] = useState("興趣組");
  const [badgeType, setBadgeType] = useState<"proficiency" | "progressive">("proficiency");
  const [requirements, setRequirements] = useState<Requirement[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (badge) {
      setName(badge.name);
      setDescription(badge.description || "");
      setIcon(badge.icon);
      setIconUrl(badge.icon_url);
      setCategory(badge.category);
      setBadgeType(badge.badge_type || "proficiency");
      loadRequirements(badge.id);
    } else {
      resetForm();
    }
  }, [badge, open]);

  const resetForm = () => {
    setName("");
    setDescription("");
    setIcon("🏅");
    setIconUrl(null);
    setCategory("興趣組");
    setBadgeType("proficiency");
    setRequirements([]);
  };

  // Get categories based on badge type
  const getCategories = () => {
    return badgeType === "progressive" ? PROGRESSIVE_CATEGORIES : PROFICIENCY_CATEGORIES;
  };

  // When badge type changes, reset category to first of that type
  const handleBadgeTypeChange = (newType: "proficiency" | "progressive") => {
    setBadgeType(newType);
    if (newType === "progressive") {
      setCategory("進度性獎章");
    } else {
      setCategory("興趣組");
    }
  };

  const loadRequirements = async (badgeId: string) => {
    const { data } = await supabase
      .from("badge_requirements")
      .select("*")
      .eq("badge_id", badgeId)
      .order("order_index");
    
    if (data) {
      setRequirements(data.map(r => ({
        id: r.id,
        name: r.name,
        description: r.description || "",
        order_index: r.order_index
      })));
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast.error("Image must be less than 2MB");
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split(".").pop();
      const fileName = `${Date.now()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from("badge-icons")
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from("badge-icons")
        .getPublicUrl(fileName);

      setIconUrl(publicUrl);
      toast.success("Icon uploaded successfully");
    } catch (error: unknown) {
      toast.error(handleDatabaseError(error, 'badge_icon_upload'));
    } finally {
      setUploading(false);
    }
  };

  const removeCustomIcon = () => {
    setIconUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const addRequirement = () => {
    setRequirements([
      ...requirements,
      { name: "", description: "", order_index: requirements.length }
    ]);
  };

  const updateRequirement = (index: number, field: keyof Requirement, value: string) => {
    const updated = [...requirements];
    updated[index] = { ...updated[index], [field]: value };
    setRequirements(updated);
  };

  const removeRequirement = (index: number) => {
    setRequirements(requirements.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("Please enter a badge name");
      return;
    }

    if (badgeType === "progressive" && requirements.length === 0) {
      toast.error("Progressive badges need at least one requirement");
      return;
    }

    if (badgeType === "progressive" && requirements.some(r => !r.name.trim())) {
      toast.error("All requirements must have a name");
      return;
    }

    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      const totalTasks = badgeType === "progressive" ? requirements.length : 1;

      if (badge) {
        // Update badge
        const { error } = await supabase
          .from("badges")
          .update({
            name: name.trim(),
            description: description.trim() || null,
            icon,
            icon_url: iconUrl,
            category,
            badge_type: badgeType,
            total_tasks: totalTasks,
          })
          .eq("id", badge.id);

        if (error) throw error;

        // Update requirements for progressive badges
        if (badgeType === "progressive") {
          // Delete old requirements
          await supabase
            .from("badge_requirements")
            .delete()
            .eq("badge_id", badge.id);

          // Insert new requirements
          const { error: reqError } = await supabase
            .from("badge_requirements")
            .insert(
              requirements.map((r, i) => ({
                badge_id: badge.id,
                name: r.name.trim(),
                description: r.description.trim() || null,
                order_index: i,
              }))
            );

          if (reqError) throw reqError;
        }

        toast.success("Badge updated successfully");
      } else {
        // Create badge
        const { data: newBadge, error } = await supabase
          .from("badges")
          .insert({
            name: name.trim(),
            description: description.trim() || null,
            icon,
            icon_url: iconUrl,
            category,
            badge_type: badgeType,
            total_tasks: totalTasks,
            created_by: user?.id,
          })
          .select()
          .single();

        if (error) throw error;

        // Insert requirements for progressive badges
        if (badgeType === "progressive" && newBadge) {
          const { error: reqError } = await supabase
            .from("badge_requirements")
            .insert(
              requirements.map((r, i) => ({
                badge_id: newBadge.id,
                name: r.name.trim(),
                description: r.description.trim() || null,
                order_index: i,
              }))
            );

          if (reqError) throw reqError;
        }

        toast.success("Badge created successfully");
      }

      onSuccess();
      onOpenChange(false);
    } catch (error: unknown) {
      toast.error(handleDatabaseError(error, 'badge'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{badge ? "Edit Badge" : "Create New Badge"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="badgeName">Badge Name</Label>
            <Input
              id="badgeName"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., First Aid"
              className="mt-1"
            />
          </div>
          
          <div>
            <Label htmlFor="badgeDescription">Description</Label>
            <Textarea
              id="badgeDescription"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what scouts need to learn for this badge"
              className="mt-1"
              rows={3}
            />
          </div>

          {/* Badge Type */}
          <div>
            <Label>Badge Type</Label>
            <div className="flex gap-3 mt-2">
              <button
                type="button"
                onClick={() => handleBadgeTypeChange("proficiency")}
                className={`flex-1 p-3 rounded-lg border-2 transition-all text-left ${
                  badgeType === "proficiency" 
                    ? "border-primary bg-primary/5" 
                    : "border-border hover:border-primary/50"
                }`}
              >
                <p className={`font-medium ${badgeType === "proficiency" ? "text-primary" : "text-foreground"}`}>
                  專章 (Proficiency)
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  完成 / 未完成
                </p>
              </button>
              <button
                type="button"
                onClick={() => handleBadgeTypeChange("progressive")}
                className={`flex-1 p-3 rounded-lg border-2 transition-all text-left ${
                  badgeType === "progressive" 
                    ? "border-primary bg-primary/5" 
                    : "border-border hover:border-primary/50"
                }`}
              >
                <p className={`font-medium ${badgeType === "progressive" ? "text-primary" : "text-foreground"}`}>
                  進度性獎章 (Progressive)
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  需完成多項要求
                </p>
              </button>
            </div>
          </div>
          
          {/* Icon Selection */}
          <div>
            <Label>Icon</Label>
            <div className="mt-2 space-y-3">
              {/* Custom icon upload */}
              <div className="flex items-center gap-3">
                {iconUrl ? (
                  <div className="relative">
                    <img 
                      src={iconUrl} 
                      alt="Badge icon" 
                      className="w-14 h-14 rounded-lg object-cover"
                    />
                    <button
                      type="button"
                      onClick={removeCustomIcon}
                      className="absolute -top-2 -right-2 w-5 h-5 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading}
                    className="w-14 h-14 rounded-lg border-2 border-dashed border-border hover:border-primary flex items-center justify-center transition-colors"
                  >
                    {uploading ? (
                      <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Upload className="w-5 h-5 text-muted-foreground" />
                    )}
                  </button>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <span className="text-sm text-muted-foreground">
                  {iconUrl ? "Custom icon uploaded" : "Upload custom icon (optional)"}
                </span>
              </div>
              
              {/* Emoji icons */}
              {!iconUrl && (
                <div className="flex flex-wrap gap-2">
                  {BADGE_ICONS.map((i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setIcon(i)}
                      className={`w-10 h-10 rounded-lg text-xl flex items-center justify-center transition-all ${
                        icon === i ? "bg-primary/20 ring-2 ring-primary" : "bg-muted hover:bg-muted/80"
                      }`}
                    >
                      {i}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          {/* Category */}
          <div>
            <Label>類別 (Category)</Label>
            <div className="flex flex-wrap gap-2 mt-2">
              {getCategories().map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    category === cat 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Requirements for Progressive Badges */}
          {badgeType === "progressive" && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label>Requirements</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addRequirement}
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add Requirement
                </Button>
              </div>
              
              <div className="space-y-3">
                {requirements.map((req, index) => (
                  <div key={index} className="flex gap-2 items-start p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center text-muted-foreground pt-2">
                      <GripVertical className="w-4 h-4" />
                      <span className="text-sm font-medium w-6">{index + 1}.</span>
                    </div>
                    <div className="flex-1 space-y-2">
                      <Input
                        value={req.name}
                        onChange={(e) => updateRequirement(index, "name", e.target.value)}
                        placeholder="Requirement name"
                      />
                      <Input
                        value={req.description}
                        onChange={(e) => updateRequirement(index, "description", e.target.value)}
                        placeholder="Description (optional)"
                        className="text-sm"
                      />
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeRequirement(index)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
                
                {requirements.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No requirements added yet. Click "Add Requirement" to start.
                  </p>
                )}
              </div>
            </div>
          )}
          
          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" disabled={loading} className="flex-1">
              {loading ? "Saving..." : badge ? "Update Badge" : "Create Badge"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default BadgeDialog;
