import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { Users, Award } from "lucide-react";

interface PatrolMember {
  id: string;
  name: string;
}

interface Badge {
  id: string;
  name: string;
  icon: string;
  icon_url: string | null;
  total_tasks: number;
}

interface BadgeProgress {
  badge_id: string;
  completed_tasks: number;
}

interface PatrolMembersDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  patrolId: string;
  patrolName: string;
}

const PatrolMembersDialog = ({ open, onOpenChange, patrolId, patrolName }: PatrolMembersDialogProps) => {
  const [members, setMembers] = useState<PatrolMember[]>([]);
  const [badges, setBadges] = useState<Badge[]>([]);
  const [progressByScout, setProgressByScout] = useState<Record<string, BadgeProgress[]>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (open && patrolId) {
      fetchData();
    }
  }, [open, patrolId]);

  const fetchData = async () => {
    setLoading(true);
    
    // Fetch patrol members
    const { data: scoutsData } = await supabase
      .from("scouts")
      .select("id, name")
      .eq("patrol_id", patrolId);
    
    if (scoutsData) {
      setMembers(scoutsData);
      
      // Fetch badge progress for all members
      const scoutIds = scoutsData.map(s => s.id);
      if (scoutIds.length > 0) {
        const { data: progressData } = await supabase
          .from("badge_progress")
          .select("scout_id, badge_id, completed_tasks")
          .in("scout_id", scoutIds);
        
        // Group progress by scout
        const grouped: Record<string, BadgeProgress[]> = {};
        progressData?.forEach(p => {
          if (!grouped[p.scout_id]) grouped[p.scout_id] = [];
          grouped[p.scout_id].push({ badge_id: p.badge_id, completed_tasks: p.completed_tasks });
        });
        setProgressByScout(grouped);
      }
    }
    
    // Fetch all badges
    const { data: badgesData } = await supabase
      .from("badges")
      .select("id, name, icon, icon_url, total_tasks");
    
    if (badgesData) setBadges(badgesData);
    
    setLoading(false);
  };

  const getEarnedBadges = (scoutId: string) => {
    const scoutProgress = progressByScout[scoutId] || [];
    return badges.filter(badge => {
      const progress = scoutProgress.find(p => p.badge_id === badge.id);
      return progress && progress.completed_tasks === badge.total_tasks;
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            {patrolName} Patrol Members
          </DialogTitle>
        </DialogHeader>
        
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : members.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No members in this patrol yet.
          </div>
        ) : (
          <div className="space-y-4 py-4">
            {members.map(member => {
              const earnedBadges = getEarnedBadges(member.id);
              return (
                <div key={member.id} className="border rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-lg font-semibold text-primary">
                        {member.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{member.name}</h4>
                      <p className="text-xs text-muted-foreground">
                        {earnedBadges.length} badge{earnedBadges.length !== 1 ? "s" : ""} earned
                      </p>
                    </div>
                  </div>
                  
                  {earnedBadges.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {earnedBadges.map(badge => (
                        <div
                          key={badge.id}
                          className="flex items-center gap-1.5 px-2 py-1 bg-accent/10 rounded-full"
                          title={badge.name}
                        >
                          <span className="w-5 h-5 flex items-center justify-center text-sm overflow-hidden rounded">
                            {badge.icon_url ? (
                              <img src={badge.icon_url} alt={badge.name} className="w-full h-full object-cover" />
                            ) : (
                              badge.icon
                            )}
                          </span>
                          <span className="text-xs font-medium text-accent truncate max-w-[100px]">
                            {badge.name}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-muted-foreground text-sm">
                      <Award className="w-4 h-4" />
                      <span>No badges earned yet</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default PatrolMembersDialog;
