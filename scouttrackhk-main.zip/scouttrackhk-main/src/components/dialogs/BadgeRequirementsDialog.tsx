import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle2, Circle, ListChecks } from "lucide-react";

interface Badge {
  id: string;
  name: string;
  description: string | null;
  icon: string;
  icon_url: string | null;
  badge_type: "proficiency" | "progressive";
}

interface Requirement {
  id: string;
  name: string;
  description: string | null;
  order_index: number;
}

interface RequirementProgress {
  requirement_id: string;
  completed: boolean;
}

interface BadgeRequirementsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  badge: Badge;
  scoutId?: string; // If provided, shows progress
}

const BadgeRequirementsDialog = ({ open, onOpenChange, badge, scoutId }: BadgeRequirementsDialogProps) => {
  const [requirements, setRequirements] = useState<Requirement[]>([]);
  const [progress, setProgress] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (open && badge.id) {
      fetchRequirements();
    }
  }, [open, badge.id, scoutId]);

  const fetchRequirements = async () => {
    setLoading(true);
    
    // Fetch requirements for this badge
    const { data: reqs } = await supabase
      .from("badge_requirements")
      .select("*")
      .eq("badge_id", badge.id)
      .order("order_index");
    
    if (reqs) {
      setRequirements(reqs);
      
      // If scoutId is provided, fetch progress
      if (scoutId && reqs.length > 0) {
        const { data: progressData } = await supabase
          .from("requirement_progress")
          .select("requirement_id, completed")
          .eq("scout_id", scoutId)
          .in("requirement_id", reqs.map(r => r.id));
        
        const progressMap: Record<string, boolean> = {};
        reqs.forEach(req => {
          const p = progressData?.find(p => p.requirement_id === req.id);
          progressMap[req.id] = p?.completed || false;
        });
        setProgress(progressMap);
      }
    }
    
    setLoading(false);
  };

  const completedCount = Object.values(progress).filter(Boolean).length;
  const progressPercent = requirements.length > 0 
    ? Math.round((completedCount / requirements.length) * 100) 
    : 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ListChecks className="w-5 h-5" />
            Badge Requirements
          </DialogTitle>
        </DialogHeader>
        
        <div className="py-4">
          {/* Badge Info */}
          <div className="flex items-center gap-4 mb-6 pb-4 border-b">
            <div className="w-14 h-14 rounded-xl bg-muted flex items-center justify-center text-2xl overflow-hidden">
              {badge.icon_url ? (
                <img src={badge.icon_url} alt={badge.name} className="w-full h-full object-cover" />
              ) : (
                badge.icon
              )}
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-foreground">{badge.name}</h3>
              {badge.description && (
                <p className="text-sm text-muted-foreground line-clamp-2">{badge.description}</p>
              )}
            </div>
          </div>
          
          {/* Progress Bar */}
          {scoutId && (
            <div className="mb-6">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-muted-foreground">Your Progress</span>
                <span className={`font-medium ${progressPercent === 100 ? "text-accent" : "text-foreground"}`}>
                  {completedCount}/{requirements.length} completed
                </span>
              </div>
              <div className="h-2 bg-progress-bg rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-300 ${
                    progressPercent === 100 ? "bg-accent" : "bg-progress-fill"
                  }`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          )}
          
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            </div>
          ) : requirements.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No requirements defined for this badge yet.
            </div>
          ) : (
            <div className="space-y-3">
              {requirements.map((req, index) => {
                const isCompleted = progress[req.id];
                return (
                  <div
                    key={req.id}
                    className={`flex items-start gap-3 p-3 rounded-lg transition-colors ${
                      isCompleted ? "bg-accent/10" : "bg-muted/50"
                    }`}
                  >
                    <div className="mt-0.5">
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 text-accent" />
                      ) : (
                        <Circle className="w-5 h-5 text-muted-foreground" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className={`font-medium ${isCompleted ? "text-accent line-through" : "text-foreground"}`}>
                        {index + 1}. {req.name}
                      </p>
                      {req.description && (
                        <p className="text-sm text-muted-foreground mt-1">{req.description}</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BadgeRequirementsDialog;
