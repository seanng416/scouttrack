import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { handleDatabaseError } from "@/lib/errorHandler";

interface Patrol {
  id: string;
  name: string;
}

interface PatrolDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  patrol?: Patrol | null;
  onSuccess: () => void;
}

const PatrolDialog = ({ open, onOpenChange, patrol, onSuccess }: PatrolDialogProps) => {
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (patrol) {
      setName(patrol.name);
    } else {
      setName("");
    }
  }, [patrol, open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("Please enter a patrol name");
      return;
    }

    setLoading(true);

    try {
      if (patrol) {
        // Update existing patrol
        const { error } = await supabase
          .from("patrols")
          .update({ name: name.trim() })
          .eq("id", patrol.id);

        if (error) throw error;
        toast.success("Patrol updated successfully");
      } else {
        // Create new patrol
        const { data: { user } } = await supabase.auth.getUser();
        
        const { error } = await supabase.from("patrols").insert({
          name: name.trim(),
          created_by: user?.id,
        });

        if (error) throw error;
        toast.success("Patrol created successfully");
      }

      onSuccess();
      onOpenChange(false);
    } catch (error: unknown) {
      toast.error(handleDatabaseError(error, 'patrol'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{patrol ? "Edit Patrol" : "Add New Patrol"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="patrolName">Patrol Name</Label>
            <Input
              id="patrolName"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Eagles, Lions, Bears"
              className="mt-1"
            />
          </div>
          
          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" disabled={loading} className="flex-1">
              {loading ? "Saving..." : patrol ? "Update" : "Create Patrol"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default PatrolDialog;
