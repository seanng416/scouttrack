import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Calendar, CheckCircle2 } from "lucide-react";
import { handleDatabaseError } from "@/lib/errorHandler";

interface Badge {
  id: string;
  name: string;
  icon: string;
  icon_url: string | null;
  total_tasks: number;
  badge_type: "proficiency" | "progressive";
}

interface Progress {
  id: string;
  badge_id: string;
  completed_tasks: number;
  completed_at: string | null;
}

interface Requirement {
  id: string;
  name: string;
  description: string | null;
  order_index: number;
}

interface RequirementProgress {
  id: string;
  requirement_id: string;
  completed: boolean;
  completed_at: string | null;
}

interface ProgressDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  scoutId: string;
  scoutName: string;
  badge: Badge;
  currentProgress?: Progress | null;
  onSuccess: () => void;
}

const ProgressDialog = ({ open, onOpenChange, scoutId, scoutName, badge, currentProgress, onSuccess }: ProgressDialogProps) => {
  const [isCompleted, setIsCompleted] = useState(false);
  const [completedAt, setCompletedAt] = useState<string>("");
  const [requirements, setRequirements] = useState<Requirement[]>([]);
  const [requirementProgress, setRequirementProgress] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(false);
  const [loadingReqs, setLoadingReqs] = useState(true);

  useEffect(() => {
    if (open) {
      setIsCompleted(currentProgress?.completed_tasks === badge.total_tasks);
      setCompletedAt(currentProgress?.completed_at?.split("T")[0] || "");
      
      if (badge.badge_type === "progressive") {
        loadRequirementsAndProgress();
      } else {
        setLoadingReqs(false);
      }
    }
  }, [currentProgress, open, badge]);

  const loadRequirementsAndProgress = async () => {
    setLoadingReqs(true);
    
    // Load requirements
    const { data: reqs } = await supabase
      .from("badge_requirements")
      .select("*")
      .eq("badge_id", badge.id)
      .order("order_index");
    
    if (reqs) {
      setRequirements(reqs);
      
      // Load requirement progress for this scout
      const { data: progress } = await supabase
        .from("requirement_progress")
        .select("*")
        .eq("scout_id", scoutId)
        .in("requirement_id", reqs.map(r => r.id));
      
      const progressMap: Record<string, boolean> = {};
      reqs.forEach(req => {
        const p = progress?.find(p => p.requirement_id === req.id);
        progressMap[req.id] = p?.completed || false;
      });
      setRequirementProgress(progressMap);
    }
    
    setLoadingReqs(false);
  };

  const toggleRequirement = (reqId: string) => {
    setRequirementProgress(prev => ({
      ...prev,
      [reqId]: !prev[reqId]
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      let completedTasks = 0;
      let badgeCompletedAt: string | null = null;

      if (badge.badge_type === "proficiency") {
        completedTasks = isCompleted ? 1 : 0;
        badgeCompletedAt = isCompleted && completedAt ? new Date(completedAt).toISOString() : null;
      } else {
        // Progressive badge - count completed requirements
        completedTasks = Object.values(requirementProgress).filter(Boolean).length;
        const allComplete = completedTasks === requirements.length;
        badgeCompletedAt = allComplete && completedAt ? new Date(completedAt).toISOString() : null;

        // Save requirement progress
        for (const req of requirements) {
          const isReqCompleted = requirementProgress[req.id] || false;
          
          const { data: existing } = await supabase
            .from("requirement_progress")
            .select("id")
            .eq("scout_id", scoutId)
            .eq("requirement_id", req.id)
            .maybeSingle();
          
          if (existing) {
            await supabase
              .from("requirement_progress")
              .update({
                completed: isReqCompleted,
                completed_at: isReqCompleted ? new Date().toISOString() : null,
              })
              .eq("id", existing.id);
          } else {
            await supabase
              .from("requirement_progress")
              .insert({
                scout_id: scoutId,
                requirement_id: req.id,
                completed: isReqCompleted,
                completed_at: isReqCompleted ? new Date().toISOString() : null,
              });
          }
        }
      }

      // Update or create badge progress
      if (currentProgress) {
        const { error } = await supabase
          .from("badge_progress")
          .update({ 
            completed_tasks: completedTasks,
            completed_at: badgeCompletedAt,
          })
          .eq("id", currentProgress.id);

        if (error) throw error;
      } else {
        const { error } = await supabase.from("badge_progress").insert({
          scout_id: scoutId,
          badge_id: badge.id,
          completed_tasks: completedTasks,
          completed_at: badgeCompletedAt,
        });

        if (error) throw error;
      }

      toast.success("Progress updated successfully");
      onSuccess();
      onOpenChange(false);
    } catch (error: unknown) {
      toast.error(handleDatabaseError(error, 'progress'));
    } finally {
      setLoading(false);
    }
  };

  const completedCount = badge.badge_type === "progressive" 
    ? Object.values(requirementProgress).filter(Boolean).length 
    : (isCompleted ? 1 : 0);
  
  const isFullyComplete = badge.badge_type === "progressive"
    ? completedCount === requirements.length && requirements.length > 0
    : isCompleted;

  const progressPercent = Math.round((completedCount / badge.total_tasks) * 100);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Update Progress</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 rounded-xl bg-muted flex items-center justify-center text-2xl overflow-hidden">
              {badge.icon_url ? (
                <img src={badge.icon_url} alt={badge.name} className="w-full h-full object-cover" />
              ) : (
                badge.icon
              )}
            </div>
            <div>
              <h3 className="font-semibold text-foreground">{badge.name}</h3>
              <p className="text-sm text-muted-foreground">for {scoutName}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {badge.badge_type === "progressive" ? "Progressive Badge" : "Proficiency Badge"}
              </p>
            </div>
          </div>
          
          {loadingReqs ? (
            <div className="flex justify-center py-8">
              <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Proficiency Badge - Simple checkbox */}
              {badge.badge_type === "proficiency" && (
                <div className="flex items-center space-x-3 p-4 bg-muted/50 rounded-lg">
                  <Checkbox
                    id="completed"
                    checked={isCompleted}
                    onCheckedChange={(checked) => setIsCompleted(checked === true)}
                  />
                  <Label htmlFor="completed" className="text-base font-medium cursor-pointer">
                    Badge Completed
                  </Label>
                </div>
              )}

              {/* Progressive Badge - Requirements list */}
              {badge.badge_type === "progressive" && (
                <div className="space-y-2">
                  <Label>Requirements ({completedCount}/{requirements.length})</Label>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {requirements.map((req, index) => (
                      <div
                        key={req.id}
                        className={`flex items-start space-x-3 p-3 rounded-lg transition-colors ${
                          requirementProgress[req.id] ? "bg-accent/10" : "bg-muted/50"
                        }`}
                      >
                        <Checkbox
                          id={`req-${req.id}`}
                          checked={requirementProgress[req.id] || false}
                          onCheckedChange={() => toggleRequirement(req.id)}
                          className="mt-0.5"
                        />
                        <div className="flex-1">
                          <Label 
                            htmlFor={`req-${req.id}`} 
                            className={`cursor-pointer ${requirementProgress[req.id] ? "line-through text-muted-foreground" : ""}`}
                          >
                            {index + 1}. {req.name}
                          </Label>
                          {req.description && (
                            <p className="text-xs text-muted-foreground mt-1">{req.description}</p>
                          )}
                        </div>
                        {requirementProgress[req.id] && (
                          <CheckCircle2 className="w-5 h-5 text-accent shrink-0" />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Progress bar */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Progress</span>
                  <span className={`font-medium ${isFullyComplete ? "text-accent" : "text-foreground"}`}>
                    {progressPercent}%
                  </span>
                </div>
                <div className="h-3 bg-progress-bg rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-300 ${
                      isFullyComplete ? "bg-accent" : "bg-progress-fill"
                    }`}
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>

              {/* Completion Date */}
              {isFullyComplete && (
                <div>
                  <Label htmlFor="completedAt" className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Completion Date
                  </Label>
                  <Input
                    id="completedAt"
                    type="date"
                    value={completedAt}
                    onChange={(e) => setCompletedAt(e.target.value)}
                    className="mt-1"
                  />
                </div>
              )}
              
              <div className="flex gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="flex-1">
                  Cancel
                </Button>
                <Button type="submit" disabled={loading} className="flex-1">
                  {loading ? "Saving..." : "Update Progress"}
                </Button>
              </div>
            </form>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ProgressDialog;
