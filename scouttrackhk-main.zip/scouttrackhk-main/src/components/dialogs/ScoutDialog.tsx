import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Eye, EyeOff, Copy } from "lucide-react";
import { handleDatabaseError } from "@/lib/errorHandler";

type ScoutPosition = "spl" | "pl" | "apl" | "member";

const positionOptions: { value: ScoutPosition; label: string }[] = [
  { value: "spl", label: "團隊長 (SPL)" },
  { value: "pl", label: "小隊長 (PL)" },
  { value: "apl", label: "副隊長 (APL)" },
  { value: "member", label: "團員 (Member)" },
];

interface Patrol {
  id: string;
  name: string;
}

interface Scout {
  id: string;
  name: string;
  patrol_id: string | null;
  user_id: string | null;
  username: string | null;
  position?: ScoutPosition;
}

interface ScoutDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  scout?: Scout | null;
  patrols: Patrol[];
  onSuccess: () => void;
}

const generateUsername = (name: string) => {
  // Generate a username from the name + random numbers
  const baseName = name.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 8);
  const randomNum = Math.floor(Math.random() * 1000).toString().padStart(3, "0");
  return `${baseName}${randomNum}`;
};

const ScoutDialog = ({ open, onOpenChange, scout, patrols, onSuccess }: ScoutDialogProps) => {
  const [name, setName] = useState("");
  const [patrolId, setPatrolId] = useState<string>("");
  const [position, setPosition] = useState<ScoutPosition>("member");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [createAccount, setCreateAccount] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (scout) {
      setName(scout.name);
      setPatrolId(scout.patrol_id || "");
      setPosition(scout.position || "member");
      setUsername(scout.username || "");
      setPassword("");
      setCreateAccount(false);
    } else {
      setName("");
      setPatrolId("");
      setPosition("member");
      setUsername("");
      setPassword("");
      setCreateAccount(false);
    }
  }, [scout, open]);

  const handleNameChange = (newName: string) => {
    setName(newName);
    // Auto-generate username when creating new scout
    if (!scout && createAccount && newName.length >= 2) {
      setUsername(generateUsername(newName));
    }
  };

  const handleCreateAccountChange = (checked: boolean) => {
    setCreateAccount(checked);
    if (checked && name.length >= 2) {
      setUsername(generateUsername(name));
      // Generate a random password
      setPassword(Math.random().toString(36).slice(-8));
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard`);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("Please enter a name");
      return;
    }

    if (createAccount && !scout) {
      if (!username.trim()) {
        toast.error("Please enter a User ID");
        return;
      }
      if (password.length < 6) {
        toast.error("Password must be at least 6 characters");
        return;
      }
    }

    setLoading(true);

    try {
      if (scout) {
        // Update existing scout
        const { error } = await supabase
          .from("scouts")
          .update({
            name: name.trim(),
            patrol_id: patrolId || null,
            position: position,
          })
          .eq("id", scout.id);

        if (error) throw error;
        toast.success("Scout updated successfully");
      } else {
        // Create new scout - use edge function for secure account creation
        const usernameToSave = createAccount ? username.trim().toLowerCase() : null;
        
        if (createAccount) {
          // Use edge function to create scout with account (avoids session juggling)
          const { data, error } = await supabase.functions.invoke('create-scout-account', {
            body: {
              name: name.trim(),
              username: usernameToSave,
              password: password,
              patrolId: patrolId || null,
              position: position,
            },
          });

          if (error) {
            toast.error("Failed to create scout account. Please try again.");
            setLoading(false);
            return;
          }

          if (data?.error) {
            toast.error(data.error);
            setLoading(false);
            return;
          }

          toast.success(
            <div>
              <p className="font-medium">Scout added with login credentials!</p>
              <p className="text-sm mt-1">User ID: {usernameToSave}</p>
              <p className="text-sm">Password: {password}</p>
            </div>,
            { duration: 10000 }
          );
        } else {
          // Create scout without account
          const { data: { user } } = await supabase.auth.getUser();
          
          const { error } = await supabase.from("scouts").insert({
            name: name.trim(),
            patrol_id: patrolId || null,
            position: position,
            user_id: null,
            username: null,
            created_by: user?.id,
          });

          if (error) throw error;
          toast.success("Scout added successfully");
        }
      }

      onSuccess();
      onOpenChange(false);
    } catch (error: unknown) {
      toast.error(handleDatabaseError(error, 'scout'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{scout ? "Edit Scout" : "Add New Scout"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="scoutName">Name</Label>
            <Input
              id="scoutName"
              value={name}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="Scout's full name"
              className="mt-1"
            />
          </div>
          
          <div>
            <Label htmlFor="patrol">Patrol</Label>
            <Select value={patrolId} onValueChange={setPatrolId}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Select a patrol" />
              </SelectTrigger>
              <SelectContent>
                {patrols.map((patrol) => (
                  <SelectItem key={patrol.id} value={patrol.id}>
                    {patrol.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="position">Position</Label>
            <Select value={position} onValueChange={(val) => setPosition(val as ScoutPosition)}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Select position" />
              </SelectTrigger>
              <SelectContent>
                {positionOptions.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {!scout && (
            <>
              <div className="pt-4 border-t">
                <div className="flex items-center space-x-2 mb-4">
                  <input
                    type="checkbox"
                    id="createAccount"
                    checked={createAccount}
                    onChange={(e) => handleCreateAccountChange(e.target.checked)}
                    className="rounded border-border"
                  />
                  <Label htmlFor="createAccount" className="cursor-pointer">
                    Create login account for this scout
                  </Label>
                </div>
                
                {createAccount && (
                  <div className="space-y-3 animate-in slide-in-from-top-2">
                    <div>
                      <Label htmlFor="scoutUsername">User ID</Label>
                      <div className="flex gap-2 mt-1">
                        <Input
                          id="scoutUsername"
                          value={username}
                          onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9]/g, ""))}
                          placeholder="e.g., johnsmith123"
                          className="flex-1"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => copyToClipboard(username, "User ID")}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        The scout will use this to log in
                      </p>
                    </div>
                    <div>
                      <Label htmlFor="scoutPassword">Password</Label>
                      <div className="flex gap-2 mt-1">
                        <div className="relative flex-1">
                          <Input
                            id="scoutPassword"
                            type={showPassword ? "text" : "password"}
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Minimum 6 characters"
                            className="pr-10"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                          >
                            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => copyToClipboard(password, "Password")}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Share these credentials with the scout securely
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}

          {scout?.username && (
            <div className="pt-4 border-t">
              <p className="text-sm text-muted-foreground">
                <span className="font-medium">User ID:</span> {scout.username}
              </p>
            </div>
          )}
          
          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" disabled={loading} className="flex-1">
              {loading ? "Saving..." : scout ? "Update" : "Add Scout"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ScoutDialog;
