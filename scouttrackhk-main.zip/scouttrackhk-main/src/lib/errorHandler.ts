/**
 * Centralized error handler to prevent exposing database internals to users.
 * Maps database error codes to user-friendly messages.
 */

interface PostgresError {
  code?: string;
  message?: string;
  details?: string;
}

export const handleDatabaseError = (error: PostgresError | Error | unknown, context?: string): string => {
  // Log the full error for debugging (only in development)
  if (import.meta.env.DEV) {
    console.error(`Database error${context ? ` in ${context}` : ''}:`, error);
  }

  // Type guard for PostgresError
  const pgError = error as PostgresError;
  
  // Map PostgreSQL error codes to user-friendly messages
  if (pgError?.code) {
    switch (pgError.code) {
      case '23505': // Unique violation
        return 'This item already exists. Please try a different value.';
      case '23503': // Foreign key violation
        return 'Cannot complete this operation. A related record may be missing.';
      case '23502': // Not null violation
        return 'Required information is missing. Please fill in all required fields.';
      case '42501': // Insufficient privilege
        return 'You do not have permission to perform this action.';
      case '42P01': // Undefined table
        return 'An error occurred. Please try again later.';
      case '22P02': // Invalid text representation
        return 'Invalid data format. Please check your input.';
      case 'PGRST116': // Row not found
        return 'The requested item was not found.';
      default:
        // Don't expose unknown error codes
        return 'An error occurred. Please try again.';
    }
  }

  // Handle authentication errors
  const errorMessage = (error as Error)?.message?.toLowerCase() || '';
  if (errorMessage.includes('invalid login credentials')) {
    return 'Invalid credentials. Please check and try again.';
  }
  if (errorMessage.includes('email not confirmed')) {
    return 'Please confirm your email address before signing in.';
  }
  if (errorMessage.includes('already registered')) {
    return 'This email is already registered. Please sign in instead.';
  }

  // Generic fallback - never expose raw error messages
  return 'An unexpected error occurred. Please try again.';
};

/**
 * Specific error handler for authentication-related operations
 */
export const handleAuthError = (error: Error | unknown): string => {
  const errorMessage = (error as Error)?.message?.toLowerCase() || '';
  
  if (errorMessage.includes('invalid login credentials')) {
    return 'Invalid username or password.';
  }
  if (errorMessage.includes('email not confirmed')) {
    return 'Please confirm your email before signing in.';
  }
  if (errorMessage.includes('already registered')) {
    return 'This email is already registered.';
  }
  if (errorMessage.includes('password')) {
    return 'Invalid username or password.';
  }
  if (errorMessage.includes('user not found')) {
    return 'Invalid username or password.';
  }
  
  return 'Authentication failed. Please try again.';
};